/* ============================================================
 * 绘画技能 + 约稿赚钱系统 (painting.js)
 * ------------------------------------------------------------
 * 技能值遵循本体惯例: 纯数值变量 V.paintingskill, 范围 0~1000,
 * 评级 F~S 与本体 <<skilllettergrade>> 宏的阈值完全一致。
 * 本体 skill() 函数白名单不含绘画, 故直接读写变量
 * (上限同样尊重 V.paintingskillmax || 1000 的本体写法)。
 * 约稿平台是手机APP("约稿"), 入口在弹窗桌面; 接单后跳转到
 * 全屏作画 passage(:: Phone Painting Work), 完成后返回原地。
 * ============================================================ */

window.PaintingMod = {};

// 懒初始化: 技能值 + 约稿元数据(旧档进入APP/接单时自动补齐)
PaintingMod.ensure = function() {
	if (typeof V.paintingskill !== "number" || isNaN(V.paintingskill)) V.paintingskill = 0; // 防脏数据: NaN 会导致评级判定全落空显示 S
	if (!V.painting) {
		V.painting = {
			currentJob: null,   // 进行中的订单 id("practice"=练习速写, "doujin:xx"=画本子)
			lastResult: null,   // 上次结算结果(供作画 passage 展示)
			jobsDone: 0,        // 累计完成接单数
			totalEarned: 0,     // 累计稿费(便士, £1=100)
			doujins: [],        // 画好的本子库存(未发布/已发布)
			_dseq: 0,           // 本子自增 id
		};
	}
	// 旧档兼容: 补本子库存字段
	if (!V.painting.doujins) V.painting.doujins = [];
	if (typeof V.painting._dseq !== "number") V.painting._dseq = 0;
	/* 绘画器材(手机店购买):
	   sketchbook 速写本 £15 — 解锁练习速写
	   tablet     数位板 £120 — 解锁约稿 + 画本子
	   旧档兼容: 已完成过接单的玩家视为早有全套器材 */
	if (!V.paintingGear) {
		V.paintingGear = { sketchbook: false, tablet: false };
		if ((V.painting.jobsDone || 0) > 0) {
			V.paintingGear.sketchbook = true;
			V.paintingGear.tablet = true;
		}
	}
};

// 器材检查: "practice" 只需任一器材; 约稿/画本子需要数位板
PaintingMod.hasGear = function(kind) {
	if (!V.paintingGear) return false;
	if (kind === "practice") return V.paintingGear.sketchbook || V.paintingGear.tablet;
	return !!V.paintingGear.tablet;
};

// 评级字母(阈值与本体 skilllettergrade 宏一致, 供 JS 判断升级)
PaintingMod.grade = function(v) {
	if (v <= 0) return "F";
	if (v <= 100) return "F+";
	if (v <= 200) return "D";
	if (v <= 300) return "D+";
	if (v <= 400) return "C";
	if (v <= 500) return "C+";
	if (v <= 600) return "B";
	if (v <= 700) return "B+";
	if (v <= 800) return "A";
	if (v <= 900) return "A+";
	return "S";
};

// 当前评级区间内的进度(0~100), 供技能条分桶显示
PaintingMod.gradePct = function(v) {
	if (v >= 1000) return 100;
	return Math.floor(v % 100);
};

// 随机取一句文案
PaintingMod.pick = function(arr) {
	return arr[Math.floor(Math.random() * arr.length)];
};

// 随机整数 [lo, hi](本地助手, 不跨文件依赖 yenote.js 的私有函数)
PaintingMod.randInt = function(lo, hi) {
	return lo + Math.floor(Math.random() * (hi - lo + 1));
};

// ==================== 约稿档位 ====================
// req=接单所需画技; minutes=耗时(分钟); pay=[最低,最高]稿费(便士); exp=完成时画技成长
PaintingMod.Tiers = [
	{ id: "t1", name: "新手头像单",   req: 0,   minutes: 60,  pay: [800, 1600],    exp: 10, desc: "群里发的低价练习单，画个Q版头像，要求不高。" },
	{ id: "t2", name: "二次元头像单", req: 120, minutes: 90,  pay: [2500, 4500],   exp: 16, desc: "同人圈常客单，要带简单背景，甲方审美挑剔。" },
	{ id: "t3", name: "表情包约稿",   req: 260, minutes: 120, pay: [5000, 9000],   exp: 22, desc: "一套九枚的动态表情包，甲方改稿改得特别勤。" },
	{ id: "t4", name: "全身彩稿",     req: 450, minutes: 180, pay: [10000, 17000], exp: 30, desc: "带场景带光效的完整立绘，别画崩，别拖稿。" },
	{ id: "t5", name: "商业插画单",   req: 700, minutes: 240, pay: [20000, 32000], exp: 42, desc: "正经公司的委托单，交稿质量决定长期口碑。" },
];

PaintingMod.getTier = function(id) {
	return PaintingMod.Tiers.find(t => t.id === id) || null;
};

// ==================== 画本子档位(画完存库存, 去小黄书/JM 发布变现) ====================
// req=所需画技; exhibReq=所需曝露度(画🔞本子要放得开); minutes=耗时; exp=画技成长;
// spice=发布时的尺度等级(复用小黄书风险体系); fans/likes/tips=发布收益基数;
// titles=成稿随机书名池
PaintingMod.DoujinTiers = [
	{ id: "d1", name: "草稿短漫",   req: 0,   exhibReq: 0,  minutes: 60,  exp: 9,  spice: 1,
	  desc: "几页的小短漫，线条潦草但有爱。",
	  fans: [10, 30],   likes: [20, 80],    tips: [0, 200],
	  titles: ["课间十分钟", "夏日速写集", "随手涂的日常", "窗台上的猫"] },
	{ id: "d2", name: "全彩同人本", req: 200, exhibReq: 0,  minutes: 150, exp: 20, spice: 1,
	  desc: "全彩印刷级的完整同人本，圈内会有口皆碑的那种。",
	  fans: [40, 120],  likes: [150, 500],  tips: [300, 1200],
	  titles: ["虹色心跳", "夏日限定回忆", "星轨与你", "放课后的约定"] },
	{ id: "d3", name: "🔞同人本",   req: 400, exhibReq: 20, minutes: 240, exp: 30, spice: 3,
	  desc: "深夜向成人同人本，发到小黄书上会炸出大量同好。",
	  fans: [150, 500], likes: [800, 3000], tips: [2000, 9000],
	  titles: ["深夜心跳本", "大人的秘密画册", "禁区幻想", "不可以用手碰的地方"] },
];

PaintingMod.getDoujin = function(id) {
	return PaintingMod.DoujinTiers.find(t => t.id === id) || null;
};

// ==================== 动作入口(弹窗按钮调用) ====================
// 接单: 校验画技门槛后记录订单并跳转到全屏作画 passage; 需要数位板
PaintingMod.start = function(id) {
	PaintingMod.ensure();
	if (!V.Phone || !PhoneMod.isWorking()) return;
	if (!PaintingMod.hasGear("commission")) return;
	const tier = PaintingMod.getTier(id);
	if (!tier || V.paintingskill < tier.req) return;
	V.painting.currentJob = id;
	PhoneMod.PhoneTo("Phone Painting Work");
};

// 练习速写: 30分钟, 只涨画技没有收入; 需要速写本或数位板
PaintingMod.practice = function() {
	PaintingMod.ensure();
	if (!V.Phone || !PhoneMod.isWorking()) return;
	if (!PaintingMod.hasGear("practice")) return;
	V.painting.currentJob = "practice";
	PhoneMod.PhoneTo("Phone Painting Work");
};

// 画本子: 校验画技/曝露度门槛后进入作画 passage, 完成后本子入库存; 需要数位板
PaintingMod.startDoujin = function(id) {
	PaintingMod.ensure();
	if (!V.Phone || !PhoneMod.isWorking()) return;
	if (!PaintingMod.hasGear("commission")) return;
	const tier = PaintingMod.getDoujin(id);
	if (!tier || V.paintingskill < tier.req) return;
	if (tier.exhibReq && (V.exhibitionism || 0) < tier.exhibReq) return;
	V.painting.currentJob = "doujin:" + id;
	PhoneMod.PhoneTo("Phone Painting Work");
};

// ==================== 结算(作画 passage 渲染时调用) ====================
/* 质量三档掷骰: 翻车(只拿定金)/完成(全额)/精品(1.3倍+口碑)。
   margin=画技-门槛, 画技越高于门槛翻车率越低、越容易出精品。
   结果写入 V.painting.lastResult; currentJob 立即清空以防重复结算。 */
PaintingMod.resolve = function() {
	PaintingMod.ensure();
	const id = V.painting.currentJob;
	if (!id) return null; // 没有进行中的订单, 防止重复结算

	const res = { tierName: "", quality: "done", pay: 0, exp: 0, before: "", after: "", minutes: 0 };

	// 练习分支: 固定30分钟, 成长3~5点, 无稿费
	if (id === "practice") {
		res.tierName = "练习速写";
		res.minutes = 30;
		res.quality = "practice";
		res.exp = 3 + Math.floor(Math.random() * 3);
		res.before = PaintingMod.grade(V.paintingskill);
		V.paintingskill = Math.clamp(V.paintingskill + res.exp, 0, V.paintingskillmax || 1000);
		res.after = PaintingMod.grade(V.paintingskill);
		V.painting.currentJob = null;
		V.painting.lastResult = res;
		return res;
	}

	// 画本子分支: 耗时后成品入库存, 无即时收入(收入在 JM 发布时结算)
	if (id.startsWith("doujin:")) {
		const dId = id.split(":")[1];
		const tier = PaintingMod.getDoujin(dId);
		if (!tier) { V.painting.currentJob = null; return null; }
		res.tierName = tier.name;
		res.minutes = tier.minutes;
		res.exp = tier.exp;
		res.quality = "doujin";
		res.doujinId = dId;
		res.title = PaintingMod.pick(tier.titles);
		res.before = PaintingMod.grade(V.paintingskill);
		V.paintingskill = Math.clamp(V.paintingskill + res.exp, 0, V.paintingskillmax || 1000);
		res.after = PaintingMod.grade(V.paintingskill);
		// 入库存(未发布状态); 收益基数在画完时即定, 发布时按加成放大
		V.painting._dseq += 1;
		V.painting.doujins.push({
			id: V.painting._dseq,
			tierId: dId,
			name: res.title,
			spice: tier.spice,
			fans: PaintingMod.randInt(tier.fans[0], tier.fans[1]),
			likes: PaintingMod.randInt(tier.likes[0], tier.likes[1]),
			tips: PaintingMod.randInt(tier.tips[0], tier.tips[1]),
			day: Time.days,
			hour: Time.hour,
			posted: false,
		});
		V.painting.currentJob = null;
		V.painting.lastResult = res;
		return res;
	}

	const tier = PaintingMod.getTier(id);
	if (!tier) { V.painting.currentJob = null; return null; }

	const margin = V.paintingskill - tier.req;
	const roll = Math.floor(Math.random() * 100);
	// 翻车率: 门槛边缘 38% 起步, 画技每高出门槛 12 点降 1%, 最低 8%
	const failRate = Math.clamp(38 - Math.floor(margin / 12), 8, 55);
	let pay = tier.pay[0] + Math.floor(Math.random() * (tier.pay[1] - tier.pay[0] + 1));
	let exp = tier.exp;
	if (roll < failRate) {
		res.quality = "fail";
		pay = Math.floor(pay * 0.25);              // 翻车只拿辛苦定金
		exp = Math.max(2, Math.floor(exp * 0.5));  // 但失败也是经验
	} else if (roll >= 88 || (margin >= 150 && roll >= 70)) {
		res.quality = "great";                     // 精品: 画技碾压时更容易触发
		pay = Math.floor(pay * 1.3);
		exp = Math.floor(exp * 1.4);
	}
	res.tierName = tier.name;
	res.minutes = tier.minutes;
	res.pay = Math.max(10, Math.floor(pay / 10) * 10); // 金额取整到 10 便士
	res.exp = exp;
	res.before = PaintingMod.grade(V.paintingskill);
	V.paintingskill = Math.clamp(V.paintingskill + exp, 0, V.paintingskillmax || 1000);
	res.after = PaintingMod.grade(V.paintingskill);
	V.painting.jobsDone += 1;
	V.painting.totalEarned += res.pay;
	V.painting.currentJob = null;
	V.painting.lastResult = res;
	return res;
};

// ==================== 文案池 ====================
PaintingMod.flavorStart = [
	"你铺开数位板，戴上耳机，把甲方的要求贴在屏幕边上。",
	"画布亮起，你先落笔起了个粗略的草稿。",
	"你缩在椅子里抱着平板，笔尖在屏幕上沙沙作响。",
	"你把参考图摆满一整块屏幕，深吸一口气开工。",
];
PaintingMod.flavorFail = [
	"改到第五稿，甲方只回了一句「感觉不对，再说」，然后没了下文。",
	"手一抖，把打光图层整个糊掉了。你自己都看不下去。",
	"甲方淡淡地说「还是用回上一版吧」——那可是你删掉的版本。",
	"越画越崩，最后只能硬着头皮交了张半成品。",
];
PaintingMod.flavorDone = [
	"甲方检查了一会儿，回了个「OK，打你款」。",
	"交稿后对方爽快确认收货，还补了句「辛苦啦」。",
	"尾款到账，客户评价：完成度不错，下次再来。",
];
PaintingMod.flavorGreat = [
	"甲方连发三条消息：「太太！我可以吹爆吗！」，当场发朋友圈安利。",
	"对方看完稿子沉默了半分钟，然后主动加了价，说「求长期合作」。",
	"你的稿子被设成了对方的主页头图，评论区全是「求太太接单」。",
];
PaintingMod.flavorPractice = [
	"你画了几张手部速写，又临摹了半张立绘。",
	"颜色怎么调都不对，你划掉了三张草稿。",
	"你照着窗外的天色练了练抓型和上色。",
];
