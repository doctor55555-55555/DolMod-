/* ==========================================================================
   收音机系统(配合 moduel/hedgefunds.twee)
   通用 <<radioBlock>> widget 可挂在任何安全屋: 孤儿院卧室/伊登小屋/
   海上平台默认有收音机, 鹰塔需在塔上花50块买一台(boot.json 规则28)。
   · 镇上/陆地收音机(setup.radioBroadcastTown): 新闻 + 小镇轶事 +
     声望新闻(按 $fame.good/scrap/pimp/social/model/business 阈值),
     不限收听次数, 内容按 (day+hour) 种子轮换。
   · 远海收音机(setup.seaPlatformBroadcast): 收不到镇上频段, 只能收到
     神秘海上电台, 每天一次, 按 (day+part) 轮换 texts 数组中的内容。
     texts 目前留白, 后续往里填广播文本即可; 为空时只收到电流杂音。
   ========================================================================== */
setup.seaPlatformBroadcast = function (day, part) {
	const d = Math.max(1, Math.floor(day) || 1);
	const p = Math.max(1, Math.floor(part) || 1);
	const texts = [

	];
	if (!texts.length) {
		return "……只有沙沙的电流杂音，偶尔夹着几声听不清的、像是从很远的海面飘来的呜咽。什么也没有播报。";
	}
	const idx = (d + p) % texts.length;
	return texts[idx];
};

setup.radioBroadcastTown = function () {
	const V = State.variables;
	const seed = (Time.days || 0) * 24 + (Time.hour || 0);
	const pick = function (arr, salt) { return arr[(seed + (salt || 0)) % arr.length]; };

	/* —— 新闻 —— */
	const news = pick([
		"【镇民新闻】气象台预报：近日镇郊雾气加重，入夜后请尽量减少独自外出。",
		"【镇民新闻】码头工会宣布本周渔获丰收，市场海产价格略有回落。",
		"【镇民新闻】镇公所提醒：夜间请锁好门窗，近日有多起入室盗窃报案。",
		"【镇民新闻】学校方面发布通告，近期将加强上下学时段的校园周边巡逻。",
		"【镇民新闻】商业街新一季度的集市将在周末开市，欢迎镇民前往。",
		"【镇民新闻】警方通报：请居民远离旧工业区，该区域建筑结构存在安全隐患。",
	], 0);

	/* —— 小镇轶事 —— */
	const gossip = pick([
		"【小镇轶事】有听众来信说，凌晨在教堂墓园看见了白色的影子……主持人表示：大概是雾。",
		"【小镇轶事】农场那头获奖的公牛又跑了，这次它冲进了咖啡馆。店主表示情绪稳定。",
		"【小镇轶事】传闻有人在商业街的旧书店里买到了一本没有字的书。书店老板拒绝置评。",
		"【小镇轶事】有渔民坚称在远海看见了'会发光的岛'。港务局：那是钻井平台的灯。",
		"【小镇轶事】公园喷泉里又被人倒了洗洁精。这已是本月第三次，嫌疑人仍未抓获。",
		"【小镇轶事】据说孤儿院后厨的炖菜秘方来自一位退休水手。厨师长笑而不语。",
	], 3);

	/* —— 声望新闻(与玩家相关·正面) —— */
	const fame = V.fame || {};
	let reputation = "";
	if ((fame.scrap || 0) >= 400) {
		reputation = "【听众热议】地下搏击场最近出了个狠角色——有听众来信描述的细节，怎么听都像是在说你。";
	} else if ((fame.pimp || 0) >= 400) {
		reputation = "【听众热议】镇上某些'特殊行业'最近流传着一位新星的名字……播音员读到一半掐掉了稿子。";
	} else if ((fame.model || 0) >= 400) {
		reputation = "【听众热议】照相馆橱窗里新挂出的一组照片引起热议，据说模特是本镇的年轻人。";
	} else if ((fame.social || 0) >= 400) {
		reputation = "【听众热议】最近镇上各大聚会都在谈论一位八面玲珑的常客——走到哪里都能成为焦点。";
	} else if ((fame.business || 0) >= 400) {
		reputation = "【听众热议】商业街的商户们提到一位做生意很有一套的年轻人，口碑相当不错。";
	} else if ((fame.good || 0) >= 400) {
		reputation = "【听众热议】有位不愿透露姓名的听众来信，想感谢一位'总在别人需要时伸出援手的年轻人'。";
	} else {
		reputation = "【听众热议】本期没有与你相关的传闻。镇子很大，你的故事还没传到电波里。";
	}

	/* —— 犯罪播报(按 $crime 各类型 current 值) —— */
	const CRIME_CN = {
		assault: "暴力袭击", coercion: "胁迫", destruction: "破坏公物",
		exposure: "有伤风化", obstruction: "妨碍司法", prostitution: "非法性交易",
		resisting: "拒捕", thievery: "盗窃", petty: "小偷小摸", trespassing: "非法闯入",
	};
	const crime = V.crime || {};
	let crimeTotal = 0;
	let crimeTop = null;
	let crimeTopVal = 0;
	for (const key of Object.keys(CRIME_CN)) {
		const val = (crime[key] && crime[key].current) || 0;
		crimeTotal += val;
		if (val > crimeTopVal) { crimeTopVal = val; crimeTop = key; }
	}
	let crimeNews = "";
	if (crimeTopVal >= 2000 || crimeTotal >= 6000) {
		const cn = CRIME_CN[crimeTop] || "犯罪";
		const details = {
			thievery: "近期镇内多户人家失窃，手法如出一辙。",
			petty: "街头小偷小摸案激增，摊贩们叫苦不迭。",
			assault: "数起恶性伤人案件引起居民恐慌。",
			prostitution: "警方盯上了一桩涉及青少年的非法性交易链条。",
			exposure: "多起公共场所 indecent exposure 举报，警方已掌握体貌特征。",
			trespassing: "多处私人产业遭人翻墙闯入，监控影像已在排查中。",
			coercion: "警方接报数起胁迫案件，嫌疑人据称熟悉受害者行踪。",
			destruction: " vandals 连续破坏公共设施，镇公所悬赏征集线索。",
			obstruction: "有嫌疑人多次妨碍警方办案，已被列入重点监控名单。",
			resisting: "一名嫌疑人在执行拘捕时激烈反抗后脱逃，警方正在追缉。",
		};
		crimeNews = "【警方通缉】警方已发布通缉令，嫌疑人涉嫌" + cn + "。" + (details[crimeTop] || "系列案件正在并案调查。") + "呼吁知情者速与警方联系。";
	} else if (crimeTopVal >= 800 || crimeTotal >= 2500) {
		const cn = CRIME_CN[crimeTop] || "违法犯罪";
		crimeNews = "【治安通报】警方正在调查一系列" + cn + "案件，呼吁居民提高警惕、积极提供线索。";
	}

	/* —— 负面声望播报 —— */
	let notoriety = "";
	const pubfame = V.pubfame || {};
	if (pubfame.status === "hiding") {
		notoriety = "【坊间传闻】据传某位镇上年轻人正因丑闻避不出门，狗仔队日夜蹲守在其住处附近。播音员表示：细节不便透露。";
	} else if ((fame.pimp || 0) >= 800) {
		notoriety = "【坊间传闻】本镇某些'灰色产业'圈子里流传着一位年轻人的名字——据说连圈内人都对TA忌惮三分。主持人表示不便细说。";
	} else if ((fame.scrap || 0) >= 800 && (fame.scrap || 0) < 1500) {
		notoriety = "【坊间传闻】地下搏击场最近有位常客打法越发狠辣，有人开始担心TA在台上控制不住自己。";
	} else if (crimeTopVal >= 2000) {
		/* 通缉令级犯罪 + 有名望 = 警方觉得此人在镇上颇有人脉 */
		let hasFame = false;
		for (const fk of ["good","scrap","business","social","model","pimp"]) {
			if ((fame[fk] || 0) >= 400) { hasFame = true; break; }
		}
		if (hasFame) {
			notoriety = "【坊间传闻】警方据信已掌握嫌疑人的外貌特征，但此人似乎在镇上颇有人脉，取证不易。";
		}
	}

	return { news: news, gossip: gossip, reputation: reputation, crime: crimeNews, notoriety: notoriety };
};

/* 阁楼专属频道: 罗宾和玩家偷偷搭建的 pirate radio。
   孤儿们利用这个频道传播信息、展示自己——罗宾主持,
   其他孤儿参与, 内容偏温馨/叛逆/夜间陪伴。
   罗宾被贝利掳走($robinmissing)时, 由其他孤儿替班主持。
   玩家在任何收音机(卧室/海上/鹰塔)均可收听, 每天一次。 */
setup.radioBroadcastLoft = function () {
	const V = State.variables;
	const seed = (Time.days || 0);
	const robinMissing = V.robinmissing && V.robinmissing !== 0;

	if (robinMissing) {
		const subHosts = [
			"今晚不是罗宾的声音。一个更老成的孤儿——大概十几岁——清了清嗓子：「……晚上好。小鸟不在。我是替班主持人，代号……算了，代号就不取了。」TA顿了一下。「罗宾欠了贝利的钱，被带走了。但广播不能停——TA走之前特意叮嘱我，'每天都要播'。所以我在这里。」",
			"替班主持人的声音从话筒里传出来，比罗宾稳但少了那股调皮劲儿：「……今天的新闻：罗宾还没回来。贝利没说什么。我们在等。」角落里一个小孤儿小声问「TA什么时候回来？」，主持人沉默了两秒：「……不知道。但TA回来之前，电台不关机。」",
			"「……今晚念一段。」替班主持人的声音有点哑，「罗宾之前写了一张稿子，说'万一哪天我不在，就念这个'。我念给你们听——」TA深吸一口气，「'如果你正在听这段话，说明你在等一个人回来。我也是。我们等的是同一个人。所以你不是一个人。'」念完后阁楼安静了一会儿。",
			"一个很小的声音怯生生地接过话筒：「我、今天我来播……哥哥姐姐不在，但我记得怎么开。」TA的声音在发抖，但很认真：「……晚上好。这里是阁楼电台。罗宾不在，但我们都还在。贝利的钱……我们会想办法的。晚安。」话筒被轻轻放下的声音，然后是替班主持人低声的「做得好」。",
			"替班主持人的声音今天轻快了一点：「有消息了——罗宾应该快回来了。不知道具体是哪天，但……TA不会一直不回来的。」TA停了一下。「到时候把话筒还给TA。在这之前——」TA对着话筒轻轻吹了声口哨，走调得厉害，但和罗宾吹的一模一样。",
		];
		return subHosts[seed % subHosts.length];
	}

	const broadcasts = [
		"电流声过后，罗宾的声音从话筒里传出来，带着压低嗓门的认真劲儿：「……晚上好。这里是阁楼电台。我是你们的主持人——呃，代号'小鸟'。」TA大概是偷偷在笑。「今晚的第一条消息：孤儿院食堂的炖菜明天又要换配方了。据可靠线报，这次会加胡萝卜。消息来源要求匿名。」",
		"「……接下来是一段天气预报。」罗宾的声音一本正经，「明天多云转晴，风力三到四级。但据本台特派通讯员——就是我——的实地观测，阁楼窗户关不严，风会从缝里钻进来。请各位听众注意保暖。」角落里传来一个小孤儿憋不住的笑声。",
		"一个稚嫩的声音忽然插进来，比罗宾还小：「我、我也想说！」罗宾在旁边小声鼓励：「说吧——对着话筒。」「我想说……我想对住在学校旁边的那个人说，你的猫昨天跑到我们院子了，它很胖，我叫它……呃，它今天回去了。再见！」罗宾笑出了声：「好，这是一条寻猫启事……虽然猫已经回去了。」",
		"「……今晚念一段听众来信。」罗宾拆开一张皱巴巴的纸，「一位住在海边的听众说：'我每天都能听到远处的船笛声，有时候觉得那也是一种广播。'」TA停了一下。「我觉得说得真好。所以今晚我们给所有在海上的人点一首歌——」一阵走调的口哨声，大概是罗宾吹的。",
		"今晚的节目不是罗宾主持。一个更老成的孤儿声音响起来——大概十几岁：「……今天的新闻：镇上有三个摊贩因为争摊位吵了起来，最后是巡警来调解的。另有小道消息说，旧工业区那边又要拆了，但没人去核实。」TA顿了顿。「本台不保证消息准确性。但本台保证——比镇上的报纸好看。」",
		"罗宾的声音回来了，但今天带着点鼻音：「……抱歉，今天感冒了。但广播不能停——我们说好了每天都要播的。」TA咳嗽了一声。「今晚就简单说一句：如果你也在阁楼上，如果你也躲着不睡觉——你不是一个人。晚安。」",
		"「……今天的特别节目！」罗宾的声音很兴奋，「我们采访了一位不愿透露姓名的孤儿——」话筒递过去，一个很小的声音怯生生地说：「我叫……不告诉你。我想说，食堂的布丁很好吃。谢谢厨师长。」罗宾接回来：「好，以上就是今天的独家专访。感谢收看——收听。」",
		"电流声特别大，但罗宾的声音顽强地穿透过来：「……信号不太好，可能是天气的关系。但没关系——」TA的声音在杂音里忽大忽小，「……就算只有一个人在听，我们也……会一直播下去的。这是阁楼电台，晚安。」杂音吞没了最后一个音节。",
	];
	return broadcasts[seed % broadcasts.length];
};
