/* ============================================================
 * 小黄书(YeNote)社交平台 (yenote.js)
 * ------------------------------------------------------------
 * 手机APP「jm/小黄书」: 发日常/自拍/性感自拍/露骨照片涨粉,
 * 靠粉丝规模产生每日被动打赏收入。
 *
 * 与 DoL 本体数值联动:
 *   V.exhibitionism      曝露度特性(0~100), 决定敢不敢发大尺度,
 *                        同时线性放大涨粉/打赏(最高+50%)。
 *   V.fame.exhibitionism 暴露名声(0~1000), 越高内容越容易爆,
 *                        但发露骨帖被现实中熟人认出(社死)的概率越高。
 * 风险: 擦边/露骨帖会被平台警告→限流→封禁; 封禁期间冻结收益。
 * 阿电反应: 存过号码(V.adian._hasNumber)后, 发帖/被封会收到
 *           他青涩风格的私信(复用 PhoneMod.receiveMessage)。
 * 全部交互在手机弹窗内原地 PhoneMod.refresh() 完成, 不跳 passage。
 * ============================================================ */

window.YeNoteMod = {};

var _ynClamp = function(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); };
var _ynRand = function(lo, hi) { return lo + Math.floor(Math.random() * (hi - lo + 1)); };

/* 发帖对本体人物属性的转化:
   - spice>=1 的内容会积累暴露名声 fame.exhibitionism(随涨粉量放大, 单次封顶)
   - 被认出(recognized)时额外积累色情名声 fame.porn
   - 发大尺度内容也会缓慢推高曝露度特性(胆子越练越大) */
YeNoteMod.fameConvert = function(spice, fans, recognized) {
	if (!V.fame) return;
	if (spice >= 1) {
		const gain = Math.min(2 + Math.floor(fans / 12), 10) * spice;
		V.fame.exhibitionism = _ynClamp((V.fame.exhibitionism || 0) + gain, 0, 1000);
	}
	if (recognized) {
		V.fame.porn = _ynClamp((V.fame.porn || 0) + _ynRand(15, 40), 0, 1000);
	}
	if (spice >= 2 && typeof V.exhibitionism === "number") {
		V.exhibitionism = _ynClamp(V.exhibitionism + 1, 0, 100);
	}
};

/* 穿着诱惑力加成: 本体 V.allure 由当前穿着决定,
   发照片类内容时穿着越诱惑, 点赞与打赏越高(最多 +60%) */
YeNoteMod.allureMul = function() {
	const allure = Math.max(0, V.allure || 0);
	return 1 + Math.min(allure / 8000, 0.6);
};

// ==================== 账号数据 ====================
YeNoteMod.ensure = function() {
	if (V.Phone.YeNote) return V.Phone.YeNote;
	V.Phone.YeNote = {
		followers: 0,       // 粉丝数
		posts: [],          // 帖子(见 post() 内字段)
		totalTips: 0,       // 累计打赏(便士)
		lastPostDay: -99,   // 上次发帖的游戏日
		postsToday: 0,      // 今日已发帖数
		warned: false,      // 是否收到过平台警告(再犯升级为封禁)
		banDay: -1,         // 封禁到期日(Time.days<=banDay 即处于封禁)
		banStartDay: -1,    // 本次封禁起始日(用于被动结算时扣掉封号天数)
		settleDay: null,    // 上次被动收益结算日
		lastSettle: null,   // 离线结算摘要(打开APP时提示一次)
		lastPost: null,     // 本次即时发帖结果(高亮提示一次)
		maxSpice: 0,        // 历史发帖最高尺度 0日常/1自拍/2性感/3露骨
		_draft: "",         // 日常动态输入框绑定
		_seq: 0,            // 帖子自增 id
	};
	return V.Phone.YeNote;
};

// ==================== 发帖类型 ====================
// req=所需曝露度(0~100); spice=尺度等级; fans/likes/tip=随机区间(便士);
// risk=平台处罚基础概率; banDays=命中封禁时的天数
YeNoteMod.Kinds = [
	{ id: "daily", name: "日常动态", icon: "✍️", req: 0,  spice: 0,
	  fans: [0, 3],    likes: [0, 12],    tip: [0, 0],     risk: 0,    banDays: 0 },
	{ id: "selfie", name: "发自拍", icon: "🤳", req: 0,  spice: 1,
	  fans: [2, 9],    likes: [10, 45],   tip: [0, 60],    risk: 0.02, banDays: 0 },
	{ id: "spicy", name: "性感自拍", icon: "🔥", req: 35, spice: 2,
	  fans: [15, 55],  likes: [100, 400], tip: [200, 900], risk: 0.18, banDays: 1 },
	{ id: "lewd", name: "露骨照片", icon: "🔞", req: 55, spice: 3,
	  fans: [80, 300], likes: [500, 2200], tip: [1500, 6000], risk: 0.40, banDays: 3 },
	/* 本子发布(约稿APP画好后入库存, 在此发布; 收益基数在画作里,
	   spice 按本子档位, 🔞本子按露骨档风险处罚) */
	{ id: "doujin", name: "同人本子", icon: "📚", req: 0,  spice: 3,
	  fans: [0, 0],    likes: [0, 0],     tip: [0, 0],     risk: 0.40, banDays: 3 },
];
YeNoteMod.DAILY_LIMIT = 3; // 每日发帖上限(防刷)

YeNoteMod.getKind = function(id) {
	return YeNoteMod.Kinds.find(k => k.id === id) || null;
};

// ==================== 状态判断 ====================
YeNoteMod.isBanned = function() {
	const yn = V.Phone.YeNote;
	return !!yn && Time.days <= yn.banDay;
};
// 封禁剩余自然日(含今天)
YeNoteMod.banRemain = function() {
	const yn = V.Phone.YeNote;
	if (!yn || Time.days > yn.banDay) return 0;
	return yn.banDay - Time.days + 1;
};
YeNoteMod.canPost = function(kind) {
	if (!PhoneMod.isWorking()) return false;
	if (YeNoteMod.isBanned()) return false;
	if ((V.exhibitionism || 0) < kind.req) return false;
	const yn = V.Phone.YeNote;
	if (yn.lastPostDay === Time.days && yn.postsToday >= YeNoteMod.DAILY_LIMIT) return false;
	return true;
};

// 粉丝数缩写: 1200 -> 1.2k, 23000 -> 2.3w
YeNoteMod.fmt = function(n) {
	if (n >= 10000) return (n / 10000).toFixed(1) + "w";
	if (n >= 1000) return (n / 1000).toFixed(1) + "k";
	return String(n);
};

// ==================== 发帖 ====================
/* 结算一次发帖。结果写入 yn.lastPost(供UI高亮), 并立即 PhoneMod.refresh。
   收益受曝露度/暴露名声放大; 风险命中按 警告(限流)→封禁 升级。 */
YeNoteMod.post = function(kindId) {
	const yn = YeNoteMod.ensure();
	if (!V.Phone || !PhoneMod.isWorking()) return;
	const kind = YeNoteMod.getKind(kindId);
	if (!kind || !YeNoteMod.canPost(kind)) return;

	// 跨天先清零当日计数
	if (yn.lastPostDay !== Time.days) yn.postsToday = 0;

	// 文案: 日常用玩家草稿(空则随机), 其余类型随机配文
	let text;
	if (kindId === "daily") {
		text = (yn._draft || "").trim() || YeNoteMod.pick(YeNoteMod.flavorDailyText);
		yn._draft = "";
	} else {
		text = YeNoteMod.pick(YeNoteMod.flavorText[kindId]);
	}

	// 加成: 曝露度 0~+50%; 暴露名声 0~+40%
	const exhib = _ynClamp(V.exhibitionism || 0, 0, 100);
	const fame = _ynClamp((V.fame && V.fame.exhibitionism) || 0, 0, 1000);
	const gainMul = 1 + exhib / 100 * 0.5 + fame / 1000 * 0.4;
	// 穿着诱惑力加成: 照片类内容穿得越诱惑数据越好
	const aMul = kind.spice >= 1 ? YeNoteMod.allureMul() : 1;

	let fans = Math.round(_ynRand(kind.fans[0], kind.fans[1]) * gainMul);
	let likes = Math.round(_ynRand(kind.likes[0], kind.likes[1]) * gainMul * aMul);
	let tips = Math.round(_ynRand(kind.tip[0], kind.tip[1]) * (1 + exhib / 200) * aMul);

	// 平台风险判定
	const fameRisk = fame / 1000 * 0.22; // 暴露名声越高越容易被举报/认出
	const riskRoll = Math.random();
	let action = "ok";
	if (kind.spice >= 1 && riskRoll < kind.risk + fameRisk) {
		// 自拍类尺度低, 只警告; 性感/露骨: 首次警告, 再犯封禁
		if (kind.spice === 1 || !yn.warned) {
			action = "warn";
			yn.warned = true;
		} else {
			action = "ban";
		}
	}

	// 社死: 暴露名声很高时发露骨, 可能被现实中的人认出(争议爆粉)
	let recognized = false;
	if (kind.spice === 3 && fame >= 400 && Math.random() < 0.3) {
		recognized = true;
		fans += _ynRand(60, 150);
	}

	// 风险后果结算
	let status = "ok";
	if (action === "warn") {
		status = "limited";   // 限流: 打赏打六折
		tips = Math.round(tips * 0.6);
	} else if (action === "ban") {
		status = "removed";   // 删除+封禁: 帖子打赏清零, 争议仍带一半粉
		tips = 0;
		fans = Math.round(fans * 0.5);
		yn.banStartDay = Time.days;
		yn.banDay = Time.days + kind.banDays - 1;
	}

	// 入库
	yn._seq += 1;
	yn.posts.push({
		id: yn._seq, day: Time.days, hour: Time.hour, minute: Time.minute,
		kind: kindId, spice: kind.spice, text: text,
		likes: likes, tips: tips, status: status, recognized: recognized,
	});
	yn.followers += fans;
	yn.totalTips += tips;
	if (kind.spice > yn.maxSpice) yn.maxSpice = kind.spice;
	yn.lastPostDay = Time.days;
	yn.postsToday += 1;
	if (V.money !== undefined) V.money += tips; // 打赏即时入账(便士)

	yn.lastPost = {
		kind: kindId, name: kind.name, icon: kind.icon,
		fans: fans, likes: likes, tips: tips,
		action: action, recognized: recognized,
	};

	// 转化到本体人物属性: 暴露名声/色情名声/曝露度
	YeNoteMod.fameConvert(kind.spice, fans, recognized);
	YeNoteMod.adianReact(kind, action, recognized);
	PhoneMod.refresh();
};

// ==================== 发布本子(约稿APP画好的库存) ====================
/* doujinId=V.painting.doujins 里的本子 id。本子收益基数画完时已定,
   发布时按曝露度/暴露名声放大; 占用每日发帖名额; 🔞本子按露骨档走风险。 */
YeNoteMod.postDoujin = function(doujinId) {
	const yn = YeNoteMod.ensure();
	if (!V.Phone || !PhoneMod.isWorking()) return;
	if (YeNoteMod.isBanned()) return;
	if (yn.lastPostDay === Time.days && yn.postsToday >= YeNoteMod.DAILY_LIMIT) return;
	PaintingMod.ensure();
	const doujin = V.painting.doujins.find(d => d.id === doujinId);
	if (!doujin || doujin.posted) return;

	if (yn.lastPostDay !== Time.days) yn.postsToday = 0;

	const kind = YeNoteMod.getKind("doujin");
	// 加成: 曝露度 0~+50%; 暴露名声 0~+40%
	const exhib = _ynClamp(V.exhibitionism || 0, 0, 100);
	const fame = _ynClamp((V.fame && V.fame.exhibitionism) || 0, 0, 1000);
	const gainMul = 1 + exhib / 100 * 0.5 + fame / 1000 * 0.4;
	// 🔞本子配预览图, 穿着诱惑力影响数据
	const aMul = doujin.spice >= 3 ? YeNoteMod.allureMul() : 1;

	let fans = Math.round(doujin.fans * gainMul);
	let likes = Math.round(doujin.likes * gainMul * aMul);
	let tips = Math.round(doujin.tips * (1 + exhib / 200) * aMul);

	// 风险: 只有🔞本子(spice3)走露骨档处罚; 全龄本子安全
	let action = "ok";
	if (doujin.spice >= 3) {
		const fameRisk = fame / 1000 * 0.22;
		if (Math.random() < kind.risk + fameRisk) {
			if (!yn.warned) { action = "warn"; yn.warned = true; }
			else { action = "ban"; }
		}
	}
	// 社死: 高暴露名声发🔞本子可能被认出(争议爆粉)
	let recognized = false;
	if (doujin.spice >= 3 && fame >= 400 && Math.random() < 0.3) {
		recognized = true;
		fans += _ynRand(60, 150);
	}

	let status = "ok";
	if (action === "warn") { status = "limited"; tips = Math.round(tips * 0.6); }
	else if (action === "ban") {
		status = "removed"; tips = 0; fans = Math.round(fans * 0.5);
		yn.banStartDay = Time.days;
		yn.banDay = Time.days + kind.banDays - 1;
	}

	// 入库
	doujin.posted = true;
	yn._seq += 1;
	yn.posts.push({
		id: yn._seq, day: Time.days, hour: Time.hour, minute: Time.minute,
		kind: "doujin", spice: doujin.spice,
		text: "📚《" + doujin.name + "》画完了，放出来给大家看～",
		likes: likes, tips: tips, status: status, recognized: recognized,
	});
	yn.followers += fans;
	yn.totalTips += tips;
	if (doujin.spice > yn.maxSpice) yn.maxSpice = doujin.spice;
	yn.lastPostDay = Time.days;
	yn.postsToday += 1;
	if (V.money !== undefined) V.money += tips;

	yn.lastPost = {
		kind: "doujin", name: "本子《" + doujin.name + "》", icon: "📚",
		fans: fans, likes: likes, tips: tips,
		action: action, recognized: recognized,
	};

	// 转化到本体人物属性
	YeNoteMod.fameConvert(doujin.spice, fans, recognized);

	// 阿电反应: 🔞本子必定触发害羞私信
	if (doujin.spice >= 3) YeNoteMod.adianReact({ spice: 3 }, action, recognized);
	else YeNoteMod.adianReact({ spice: 1 }, action, recognized);
	PhoneMod.refresh();
};

// ==================== 被动收益(打开APP时按天结算) ====================
/* 粉丝每天自然增长, 且达到规模后按"历史最高尺度"产生每日打赏(有封顶)。
   幂等: 用 settleDay 记录, 每个游戏日只结算一次; 最多补发7天防读档爆炸;
   首次打开不补发; 封禁期间冻结。 */
YeNoteMod.settle = function() {
	const yn = YeNoteMod.ensure();
	if (yn.settleDay === null) { yn.settleDay = Time.days; return; }
	const days = _ynClamp(Time.days - yn.settleDay, 0, 7);
	if (days <= 0) return;

	// 扣掉离线区间 (settleDay, today] 内与封禁区间重叠的天数(封号期间不涨粉/无打赏)
	let effective = days;
	if (yn.banStartDay >= 0) {
		const bLo = Math.max(yn.banStartDay, yn.settleDay + 1);
		const bHi = Math.min(yn.banDay, Time.days);
		if (bHi >= bLo) effective -= (bHi - bLo + 1);
	}
	effective = Math.max(0, effective);

	let fansGain = 0, tipsGain = 0;
	if (effective > 0) {
		// 每自然日: 粉丝 2% 自然增长 + 按尺度的固定拉新
		var spiceBonus = [0, 4, 20, 55][yn.maxSpice] || 0;
		var perDayFans = Math.floor(yn.followers * 0.02) + spiceBonus + _ynRand(0, 6);
		fansGain = perDayFans * effective;
		// 打赏: 需100粉且发过性感以上。每粉每日贡献 + 每日封顶(便士)
		if (yn.followers >= 100 && yn.maxSpice >= 2) {
			var rate = yn.maxSpice === 3 ? 2 : 0.5;
			var cap = yn.maxSpice === 3 ? 4000 : 1000;
			var perDayTips = Math.min(Math.floor(yn.followers * rate), cap);
			tipsGain = perDayTips * effective;
		}
	}
	yn.followers += fansGain;
	yn.totalTips += tipsGain;
	if (tipsGain > 0 && V.money !== undefined) V.money += tipsGain;
	yn.lastSettle = { days: effective, fans: fansGain, tips: tipsGain };
	yn.settleDay = Time.days;
};

// UI 提示展示后清除(只提示一次)
YeNoteMod.clearNotices = function() {
	if (V.Phone.YeNote) {
		V.Phone.YeNote.lastSettle = null;
		V.Phone.YeNote.lastPost = null;
	}
};

// ==================== 阿电联动 ====================
// 按发帖尺度/处罚结果, 概率往信息APP塞一条他的青涩私信(需已存号码)
YeNoteMod.adianReact = function(kind, action, recognized) {
	try {
		if (!V.adian || !V.adian._hasNumber) return;
		let pool = null, chance = 0;
		if (action === "ban") { pool = YeNoteMod.flavorAdianBan; chance = 1; }
		else if (recognized) { pool = YeNoteMod.flavorAdianRecognized; chance = 1; }
		else if (kind.spice === 3) { pool = YeNoteMod.flavorAdianLewd; chance = 0.85; }
		else if (kind.spice === 2) { pool = YeNoteMod.flavorAdianSpicy; chance = 0.45; }
		else if (kind.spice === 1) { pool = YeNoteMod.flavorAdianSelfie; chance = 0.15; }
		if (pool && Math.random() < chance) {
			PhoneMod.receiveMessage("adian", YeNoteMod.pick(pool));
		}
	} catch (e) { /* 阿电反应失败不影响发帖主流程 */ }
};

YeNoteMod.pick = function(arr) { return arr[Math.floor(Math.random() * arr.length)]; };

// ==================== 文案池 ====================
YeNoteMod.flavorDailyText = [
	"今天天气不错，出门随便走走。",
	"摸鱼一整天，什么也没干，但很安心。",
	"分享一首最近在循环的歌。",
	"晚饭吃了顿好的，治愈。",
];
YeNoteMod.flavorText = {
	selfie: [
		"随手拍一张📸 光线刚刚好。",
		"新发型，自留纪念。",
		"今天状态不错，按了张快门。",
	],
	spicy: [
		"难得大胆一次，别问，问就是热🔥",
		"只发这一次……大概。",
		"试了下新风格，心跳好快。",
	],
	lewd: [
		"🔞 成年人的快乐，懂的都懂。",
		"这条说不定明天就没了。",
		"关灯前的小秘密，刷到算你运气。",
	],
};
// 阿电私信(青涩纯情: 易慌、结巴、嘴硬, 禁止熟练直球/自称对象)
YeNoteMod.flavorAdianSelfie = [
	"你、你今天发的那张……我刷到了。挺、挺好看的。我说完了！",
	"午饭要按时吃。……还有，照片我点赞了，手滑，不是故意的。",
];
YeNoteMod.flavorAdianSpicy = [
	"你刚发的那个……我刷到时手指都不知道往哪放。你不冷吗！",
	"那个，照片。我不是故意盯着看的……你、你注意点身边的人啊。",
	"我刷到你的更新了。评论区人多，你要是不自在我帮你一条条回……我、我随便说的。",
];
YeNoteMod.flavorAdianLewd = [
	"你快删掉！！被你同学认出来怎么办……我、我帮你盯着评论区还不行吗。",
	"这、这种也能发的吗。我差点把手机扔了。求你设成仅自己可见。",
	"我刷到时心脏快停了。你要是被人认出来我不敢想……删掉好不好。",
];
YeNoteMod.flavorAdianBan = [
	"被、被封了？……也好。你别难过，你拍什么都好看，不用发给那么多人看的。",
	"封号几天而已。要不要出来，我请你喝奶茶……就、就是普通地请一杯。",
];
YeNoteMod.flavorAdianRecognized = [
	"学校好像有人在传那张图……你这几天小心点。谁敢乱讲，我去帮你解释。",
	"我听人说好像刷到你了……你别怕，我在呢。先把定位什么的关一关？",
];
