/* ==========================================================================
   MyFirstMod - NPC 脚本 (modscript.js)
   --------------------------------------------------------------------------
   功能: 阿电 NPC 对象初始化、loveAlias 代理修复、旧档迁移、特质"阿电的恋人"注册与授予
   方法: $(document).on(':passageinit', ...) 监听 SugarCube 事件, 每次进入 passage 时
         重建 V.NPCName 中的阿电对象, 仿 setup.baseNNPC(本体 176201 行) 的字段结构
   依赖: 被 boot.json 在 scriptFileList 声明; 阿电 passage 通过 C.npc["阿电"] 别名读取
         本文件写入的对象; ngplus.js 自包含, 不互相引用
   --------------------------------------------------------------------------
   一、setup.loveAlias 代理修复 (防社交面板渲染崩溃)
   二、旧存档迁移 (英文 "Adian" → 中文 "阿电")
   三、注册 NPC 对象 (V.NPCNameList / V.NPCName, 仿罗宾字段结构)
   四、旧对象补丁 + $adian 引用同步 (数字兜底 + init 双向保险)
   五、特质: 阿电的恋人 (setup.feats 注册 + 授予检测 + 按小时被动)
   六、追踪与罗宾的外出活动 (聊天嫉妒触发)
   七、P2-D 嫉妒具象化前置标记 + 暗-A 跟踪期每日掷骰/冷却 (stalking.twee 渲染)
   八、暗-B 杀人事件 (rage>=60 选定 love>85 目标, 睡醒时结算, 墓碑在 stalking.twee)
   八补、暗-D 囚禁线 pending(rage>=90 次日起床被 <<adianKidnapCheck>> 拦截)
   九、暗-D 追捕掷骰(逃脱后递增概率)
   十、死者封禁(被杀NPC的事件池过滤 + 私域 passage prehistory 守卫)
   ========================================================================== */


$(document).on(':passageinit', function () {
	/* ---- 一、setup.loveAlias 代理修复 ----
	   relation-box 渲染 love 属性时会立即执行 setup.loveAlias[nam]() 取显示名,
	   自定义 NPC 没有这个函数会报 "is not a function" 导致整个面板崩溃。
	   用 Proxy 包装: 原版 NPC 的函数原样返回, 缺失的名字自动补 () => "Love"。 */
	try {
		if (typeof setup !== 'undefined' && setup.loveAlias && !setup.loveAlias.__adianProxy) {
			const orig = setup.loveAlias;
			setup.loveAlias = new Proxy(orig, {
				get(target, prop) {
					if (prop === '__adianProxy') return true;
					const val = target[prop];
					return typeof val === 'function' ? val : (() => "Love");
				}
			});
		}
	} catch (e) {
		try {
			if (typeof setup !== 'undefined' && setup.loveAlias && !setup.loveAlias["阿电"]) {
				setup.loveAlias["阿电"] = () => "Love";
			}
		} catch (e2) {}
	}

	/* ---- 二、旧存档迁移: 旧版本身份串是英文 "Adian", 统一改成 "阿电" ----
	   分两种情况: 只有旧条目 → 直接改名; 新旧并存(旧 boot.json 注入的幽灵
	   条目) → 删除旧条目, 避免列表里出现两个阿电。 */
	if (V.NPCNameList && Array.isArray(V.NPCNameList)) {
		const legacy = V.NPCNameList.indexOf("Adian");
		if (legacy !== -1) {
			if (V.NPCNameList.indexOf("阿电") === -1) {
				V.NPCNameList[legacy] = "阿电";
				if (V.NPCName[legacy]) {
					V.NPCName[legacy].nam = "阿电";
					V.NPCName[legacy].title = "邻居";
					V.NPCName[legacy].description = "阿电";
				}
			} else {
				V.NPCNameList.splice(legacy, 1);
				V.NPCName.splice(legacy, 1);
			}
		}
	}

	/* ---- 三、注册 NPC 对象 (仿 setup.baseNNPC, 游戏本体 176201 行) ---- */
	if (!V.NPCNameList) V.NPCNameList = [];
	if (!V.NPCName) V.NPCName = [];

	let idx = V.NPCNameList.indexOf("阿电");
	if (idx === -1) {
		V.NPCNameList.push("阿电");
		V.NPCName.push({
			/* ============ [身份字段] ============ */
			/* nam: ★全模组最关键的字段。NPC 唯一标识, 必须与 V.NPCNameList
			   里的字符串、T.npcConfig 的键名、T.importantNpcOrder 里的条目
			   三处完全一致。社交面板卡片显示的名字、配置查找、普通/主要
			   分区过滤全靠它。缺了它 NPC 会掉进普通NPC区且名字空白。 */
			nam: "阿电",
			/* title: 头衔, 卡片名字下方显示 "The {title}" */
			title: "邻居",
			/* description: 描述, <<npcrelationship>> widget 会用到 */
			description: "阿电",
			/* gender/pronoun: 性别与代词, 影响原版代词生成 (m=male) */
			gender: "male",
			pronoun: "m",
			/* type: NPC 种类 (human/wolf 等) */
			type: "human",
			/* teen/adult: 年龄段标记 */
			teen: 0,
			adult: 1,

			/* ============ [外貌字段] (面板不显示, 原版系统需要) ============ */
			penis: 1, vagina: 0,            /* 有无器官: 1有 0无 */
			penissize: 0, penisdesc: "阿电的小XX", /* 器官尺寸与描述 */
			bottomsize: 0, ballssize: 0,
			breastsize: 0, breastdesc: 0, breastsdesc: 0,
			skincolour: 0, eyeColour: 0, hairColour: 0,
			insecurity: 0,                   /* 不安全感 */

			/* ============ [状态标记] ============ */
			/* init: ★0=未见面(社交面板不渲染该卡片) 1=已见面(渲染)。
			   首次进入阿电房间时被 twee 置 1, 卡片随即出现 */
			init: 0,
			/* intro: 是否已做过自我介绍 */
			intro: 0,
			/* state: 原版剧情状态标记 (模组暂不使用, 保留字段防 undefined) */
			state: "",

			/* ============ [恋爱属性] (社交面板进度条, 0-100) ============ */
			/* ★全部从 0 开始: 本体 relation-box 只渲染 gt 0 的属性条,
			   所以刚认识时好感/信任/嫉妒全部隐藏, 被互动改变后才出现。
			   love: 好感度 — 面板"好感"红条。≥60 解锁玩家告白, 满100 阿电主动告白 */
			love: 0,
			/* dom: 信任 — 面板"信任"蓝条(复用原版支配度字段槽位)。
			   打扫/约会增加; 满100+恋爱解锁"阿电的恋人"特质 */
			dom: 0,
			/* rage: 嫉妒 — 面板"嫉妒"金条(复用原版愤怒槽位)。
			   聊天提朋友/罗宾、拒绝、分手增加; 初始0不显示 */
			rage: 0,
			/* lust: 性欲 — 面板"性欲"粉条, npcConfig 里 requirements
			   绑定 V.adian_romance===1(成为恋人才显示); 只在恋爱后的亲密
			   互动中积累, 作为情侣自愿遭遇战的前置值。分手清零 */
			lust: 0,
			/* trauma: 创伤 — 青条 (隐藏) */
			trauma: 0,
			/* corruption: 堕落 — 紫条 (隐藏) */
			corruption: 0,
			/* purity: 纯洁 — 白条 (隐藏, 图标依赖 virginity 字段) */
			purity: 0,
			/* trust: 原版罗宾专用的信任字段 (与 dom 无关, 面板不显示) */
			trust: 0,

			/* ============ [引擎内部字段] ============ */
			/* chastity: 贞操装置状态 (原版系统需要, 保留空值) */
			chastity: { penis: "", vagina: "", anus: "" },
			/* virginity: 处子身 — purity 属性图标据此切换 angel/fallen-angel */
			virginity: { vaginal: true, penile: true },
			/* socialSeed: 历史字段(旧版用于一次性播种初始属性), 现已不再播种,
		   love/dom/rage/lust 全部从 0 起, 被改变后才在社交面板出现 */
		socialSeed: 1,
	});
		idx = V.NPCNameList.indexOf("阿电");
	}

	/* ---- 四、旧对象补丁 + $adian 引用同步 ----
	   ★twee 侧一律通过 C.npc["阿电"] 读写 NPC(本体 alias2.js 同款实时
	   getter: 每次访问都重新解析 V.NPCName[index], 引用永不断)。
	   V.adian 仍同步为同一对象, 供本文件 JS 侧(特质/嫉妒追踪)读取;
	   SugarCube 每次导航克隆变量会断对象引用, 所以每个 passage 重同步。 */
	if (idx !== -1) {
			const ad = V.NPCName[idx];
			if (!ad.nam) ad.nam = "阿电";
			if (!ad.chastity) ad.chastity = { penis: "", vagina: "", anus: "" };
			if (!ad.virginity) ad.virginity = { vaginal: true, penile: true };
			/* —— 性别同步: 玩家可在本体 NPC 设置菜单(npcSettingsMenu)把阿电改成
			   女性/双性, 那里只写 pronoun/gender 两个字段, 中文代词映射与器官
			   标记需要在这里跟随重建。_pronounSig 记录上次应用值, 只在玩家
			   真的改动后才重写, 避免每 passage 白写。 —— */
			if (ad.gender === "male") ad.gender = "m";
			if (ad.gender === "female") ad.gender = "f";
			const _pro = ad.pronoun || "m";
			const _sig = _pro + "/" + (ad.gender || "");
			if (ad._pronounSig !== _sig) {
				ad._pronounSig = _sig;
				ad.pronouns = setup.adianPronounsFor(_pro);
				/* gender 决定生殖器(本体语义): m=阴茎 f=阴道 h=双性 */
				if (ad.gender === "f") { ad.penis = 0; ad.vagina = 1; }
				else if (ad.gender === "h") { ad.penis = 1; ad.vagina = 1; }
				else { ad.penis = 1; ad.vagina = 0; }
			}
		/* 四属性数字兜底: 面板只渲染 gt 0 的条, 对象若缺字段,
		   Math.clamp(undefined+n) 产出 NaN 永远不渲染, 必须补 0
		   (防御 npcNamed 重建/旧档迁移/旧档把 NaN 存成 null) */
		if (typeof ad.love !== "number" || Number.isNaN(ad.love)) ad.love = 0;
		if (typeof ad.dom !== "number" || Number.isNaN(ad.dom)) ad.dom = 0;
		if (typeof ad.rage !== "number" || Number.isNaN(ad.rage)) ad.rage = 0;
		if (typeof ad.lust !== "number" || Number.isNaN(ad.lust)) ad.lust = 0;
		if (ad.socialSeed !== 1) {
			/* 旧版曾在此播种 love=10/dom=10/rage=5, 已废弃:
			   属性条严格"有变化才出现"(gt 0 才渲染), 旧档既有的
			   非零值保留(视为已经发生的变化), 不回退。 */
			ad.socialSeed = 1;
		}
		/* 旧存档兼容: 0.0.5 及之前进过房间(init=1)但还没触发午餐相遇剧情的
		   存档, 直接视为已认识, 避免房间入口被新门禁锁死 */
		if (ad.init === 1 && !V.adian_met) V.adian_met = 1;
		/* 反向保险: 已触发相遇($adian_met=1, 房间入口/共餐/约会都正常)但 NPC
		   对象 init 丢失或被重置为 0 时(引用断裂、npcNamed 重建、旧档迁移、
		   轮回等都可能造成), 补回 init=1。否则会出现"能进阿电房间、社交面板
		   却不显示阿电卡片"的不一致——主要角色卡片只渲染 init===1 的 NPC。 */
		if (V.adian_met === 1 && ad.init !== 1) ad.init = 1;
		V.adian = ad;
	}

	/* ---- 五、特质: 阿电的恋人 ----
	   注册: setup.feats[名] = { title, desc, difficulty(1铜~5钻), series, filter, softLockable }
	   授予: earnFeat("名") 宏会写入 V.feats.currentSave[名] 并弹出特质获得界面;
	         它在作弊/statFreeze 下会提前返回, 所以弹不出时我们直接静默补写, 保证不丢。
	   条件(全部满足才授予):
	         V.adian_romance === 1   已告白成为恋人 (告白成功置 1)
	         V.adian.dom >= 100      信任刷满 (dom 字段 0-100, 面板显示 Trust)
	     ——即必须先成为恋人、再把信任刷满才触发, 符合"攻略奖励"定位。
	   效果(按游戏内小时结算, 用 Time.days*24+Time.hour 做单调小时序号):
	         压力恢复更快: 每经过 1 小时额外 -50 压力
	         自控力缓增:   每经过 1 小时 willpower +10 (上限 1000)
	     statFreeze/读档跳时不补发, 避免失衡。 */
	try {
		const ADIAN_FEAT = "阿电的恋人";
		if (typeof setup !== "undefined" && setup.feats && !setup.feats[ADIAN_FEAT]) {
			setup.feats[ADIAN_FEAT] = {
				title: "阿电的恋人",
				desc: "与阿电相恋，并赢得了他毫无保留的信任。压力随时间恢复得更快，意志力（自控力）会稳步增长。",
				difficulty: 2,
				series: "adian",
				filter: ["All", "General"],
				softLockable: true,
			};
		}

		if (V.feats && V.adian) {
			if (!V.feats.currentSave) V.feats.currentSave = {};

			/* —— 授予检测 —— */
			if (!V.feats.currentSave[ADIAN_FEAT] && V.adian_romance === 1 && (V.adian.dom || 0) >= 100) {
				try {
					if (typeof Wikifier !== "undefined") Wikifier.wikifyEval('<<earnFeat "' + ADIAN_FEAT + '">>');
				} catch (e) {}
				/* earnFeat 在作弊/statFreeze 下会跳过, 这里兜底静默写入 */
				if (!V.feats.currentSave[ADIAN_FEAT]) V.feats.currentSave[ADIAN_FEAT] = new Date();
			}

			/* —— 特质被动效果(按小时) —— */
			if (
				V.feats.currentSave[ADIAN_FEAT] &&
				!V.statFreeze &&
				typeof Time !== "undefined" &&
				typeof Time.days === "number" &&
				typeof Time.hour === "number"
			) {
				const hourIndex = Time.days * 24 + Time.hour;
				if (typeof V.adian._featHour !== "number") V.adian._featHour = hourIndex;
				const dh = hourIndex - V.adian._featHour;
				if (dh > 0 && dh < 100) {
					for (let i = 0; i < dh; i++) {
						if (typeof V.stress === "number") V.stress = Math.max(0, V.stress - 50);
						if (typeof V.willpower === "number") V.willpower = Math.clamp(V.willpower + 10, 0, 1000);
					}
					V.adian._featHour = hourIndex;
				} else if (dh >= 100 || dh < 0) {
					/* 长时间未玩/读档时间跳跃: 不补发, 重置基准即可 */
					V.adian._featHour = hourIndex;
				}
			}

			/* —— 负面特质: 悼亡(暗-B 杀人后获得) ——
			   授予: 阿电杀人(_hasKilled 有值)即获得。
			   被动(按游戏内小时): 压力持续 +30, 疲劳 +2, 每2小时创伤 +1。
			   闪回的大量即时负面在 :: Adian Flashback 内结算。
			   消除: 哈珀医生心理辅导(:: Adian Grief Counseling)做满3次后
			   置 _griefCured=1 并删除特质; 此后再不授予。 */
			const GRIEF_FEAT = "悼亡";
			if (typeof setup !== "undefined" && setup.feats && !setup.feats[GRIEF_FEAT]) {
				setup.feats[GRIEF_FEAT] = {
					title: "悼亡",
					desc: "一个熟悉的人永远离开了你。压力、疲劳与创伤会随时间不断累积:走进TA曾经出现的地方时,回忆可能毫无征兆地将你吞没,造成巨大的精神冲击。医院的心理辅导或许能帮你走出来。",
					difficulty: 3,
					series: "adian",
					filter: ["All", "General"],
					softLockable: false,
				};
			}
			if (V.adian._hasKilled && !V.adian._griefCured && !V.feats.currentSave[GRIEF_FEAT]) {
				/* 杀人当天不触发闪回(起床通知已足够冲击), 并初始化被动基准 */
				V.adian._lastFlashbackDay = Time.days;
				if (typeof V.adian._griefHour !== "number") V.adian._griefHour = Time.days * 24 + Time.hour;
				try {
					if (typeof Wikifier !== "undefined") Wikifier.wikifyEval('<<earnFeat "' + GRIEF_FEAT + '">>');
				} catch (e) {}
				if (!V.feats.currentSave[GRIEF_FEAT]) V.feats.currentSave[GRIEF_FEAT] = new Date();
			}
			if (
				V.feats.currentSave[GRIEF_FEAT] &&
				!V.statFreeze &&
				V.adian._hasKilled &&
				typeof Time !== "undefined" &&
				typeof Time.days === "number" &&
				typeof Time.hour === "number"
			) {
				const gIdx = Time.days * 24 + Time.hour;
				if (typeof V.adian._griefHour !== "number") V.adian._griefHour = gIdx;
				const gdh = gIdx - V.adian._griefHour;
				if (gdh > 0 && gdh < 100) {
					/* tiredness 量表 0-2000, <<tiredness>> widget 内部 ×20,
					   故 JS 侧 +40 原始值/小时 = widget +2, 与宏效果一致 */
					const tireMax = (typeof C !== "undefined" && C.tiredness && C.tiredness.max) || 2000;
					for (let gi = 0; gi < gdh; gi++) {
						if (typeof V.stress === "number") V.stress = Math.min(10000, V.stress + 30);
						if (typeof V.tiredness === "number") V.tiredness = Math.clamp(V.tiredness + 40, 0, tireMax);
						if (gi % 2 === 1 && typeof V.trauma === "number") V.trauma = Math.min(10000, V.trauma + 1);
					}
					V.adian._griefHour = gIdx;
				} else if (gdh >= 100 || gdh < 0) {
					V.adian._griefHour = gIdx;
				}
			}
		}
	} catch (e) {}

	/* ---- 六、追踪与罗宾的外出活动 ----
	   当玩家进入 Robin Walk/Forest/Cinema/Amusements 等 passage 时记录当天,
	   次日与阿电聊天时必定触发嫉妒文本(_chat=2)。 */
	if (V.passage && /^Robin (Walk|Forest|Cinema|Amusements|Walk School|Walk Cinema)/.test(V.passage)) {
		if (!V.adian) V.adian = {};
		V.adian._robinOutDay = Time.days;
	}

	/* ---- 七、P2-D 嫉妒具象化 + 暗-A 跟踪期 ----
	   7a. 嫉妒具象化前置标记: 玩家访问过任一可攻略 NPC 的互动 passage 后置
	       _jealousReady=1, 下次进阿电房间(且 rage>=20、距上次事件>=7天)
	       由 modcontent.twee 的 Adian Room 渲染嫉妒事件入口, 事件内清标记。
	   7b. 跟踪期每日掷骰(每天首次导航只掷一次, 用 _stalkRollDay 防重复):
	       激活 = rage>=50 或 告白被拒7天冷处理期内(拒绝也会触发跟踪)。
	       环境文本 15%, 交互事件 30% 且距上次事件>=3天。
	       拒绝告白当天的保底事件在 Adian Confession Reject passage 内直接
	       set _stalkEvent=1, 因本掷骰每天只跑一次, 保底值不会被覆盖。
	       rage 降回50以下且出了拒绝周 → 当天立即清零, 文本/链接全消失。 */
	try {
		if (V.adian_met === 1 && V.adian && typeof Time !== "undefined" && typeof Time.days === "number") {
			/* 新字段数字兜底, 防 undefined 进 twee 的 gte/is 比较 */
			if (typeof V.adian._jealousEventDay !== "number") V.adian._jealousEventDay = 0;
			if (typeof V.adian._stalkEventCooldown !== "number") V.adian._stalkEventCooldown = 0;
			if (typeof V.adian._stalkTextDay !== "number") V.adian._stalkTextDay = 0;
			if (typeof V.adian._stalkEventDay !== "number") V.adian._stalkEventDay = 0;

			/* 7a. 与其他可攻略 NPC 互动过 */
			if (V.passage && /^(Robin|Whitney|Kylar|Alex|Avery|Eden|Great Hawk|Black Wolf|Sydney)(\s|$)/.test(V.passage)) {
				V.adian._jealousReady = 1;
			}

			/* 7b. 跟踪激活条件 */
			const _rage = V.adian.rage || 0;
			const _rejected = V.adian_confession_state === "rejected" &&
				typeof V.adian_reject_day === "number" &&
				(Time.days - V.adian_reject_day) < 7;
			const _stalking = _rage >= 50 || _rejected;

			if (V.adian._stalkRollDay !== Time.days) {
				V.adian._stalkRollDay = Time.days;
				if (_stalking) {
					if (Math.random() < 0.15) {
						V.adian._stalkText = 1;
						V.adian._stalkTextPick = Math.floor(Math.random() * 4);
						V.adian._stalkTextDay = Time.days;
					} else {
						V.adian._stalkText = 0;
					}
					if (Math.random() < 0.30 && (Time.days - V.adian._stalkEventCooldown) >= 3) {
						V.adian._stalkEvent = 1;
						V.adian._stalkEventDay = Time.days;
					} else {
						V.adian._stalkEvent = 0;
					}
				} else {
					V.adian._stalkText = 0;
					V.adian._stalkEvent = 0;
				}
			} else if (!_stalking) {
				/* 当天已掷过骰但跟踪条件中途消失(rage 被降低/拒绝周结束) */
				V.adian._stalkText = 0;
				V.adian._stalkEvent = 0;
			}
		}
	} catch (e) {}

	/* ---- 八、暗-B 杀人事件 (rage>=60 && 有其他NPC love>85, 一生一次) ----
	   选定目标: rage>=60 且未杀过人时, 从所有 love>85 的其他NPC中随机选一名,
	   记 _killTarget/_killPending/_killPendingDay。动手前 rage 降回60以下
	   则取消(悬崖勒马)。
	   执行时机: 玩家在 Bedroom/Sea Platform Interior/Eden Cabin 睡醒时
	   (要求跨天: Time.days > _killPendingDay, 防白天进卧室立即触发)。
	   结算: _hasKilled=NPC名, _killDay=当天, rage=max(30, rage-30);
	   被杀NPC love/dom/rage/lust/trauma 清零(社交面板属性条全部隐藏),
	   头衔改"已死亡"(卡片保留但标记死亡), 清空其 $loveInterest 恋人槽;
	   _killNotifyDay=当天 → 起床 passage 的 <<adianKillWake>> 显示通知。 */
	try {
		if (V.adian_met === 1 && V.adian && typeof Time !== "undefined" && typeof Time.days === "number") {
			if (!V.adian._hasKilled) {
				if (V.adian._killPending) {
					if ((V.adian.rage || 0) < 60) {
						V.adian._killPending = 0;
						V.adian._killTarget = "";
					}
				} else if ((V.adian.rage || 0) >= 60 && Array.isArray(V.NPCNameList)) {
					const cands = [];
					for (let i = 0; i < V.NPCNameList.length; i++) {
						const n = V.NPCName[i];
						if (n && n.nam && n.nam !== "阿电" && typeof n.love === "number" && n.love > 85) cands.push(n.nam);
					}
					if (cands.length) {
						V.adian._killTarget = cands[Math.floor(Math.random() * cands.length)];
						V.adian._killPending = 1;
						V.adian._killPendingDay = Time.days;
					}
				}
				if (
					V.adian._killPending && V.adian._killTarget &&
					typeof V.adian._killPendingDay === "number" && Time.days > V.adian._killPendingDay &&
					["Bedroom", "Sea Platform Interior", "Eden Cabin"].indexOf(V.passage) !== -1
				) {
					const tname = V.adian._killTarget;
					V.adian._hasKilled = tname;
					V.adian._killDay = Time.days;
					V.adian.rage = Math.max(30, (V.adian.rage || 0) - 30);
					V.adian._killPending = 0;
					V.adian._killNotifyDay = Time.days;
					const ti = V.NPCNameList.indexOf(tname);
					if (ti !== -1 && V.NPCName[ti]) {
						const tn = V.NPCName[ti];
						tn.title = "已死亡";
						tn.love = 0; tn.dom = 0; tn.rage = 0; tn.lust = 0; tn.trauma = 0;
					}
					if (V.loveInterest) {
						for (const slot of ["primary", "secondary", "tertiary"]) {
							if (V.loveInterest[slot] === tname) V.loveInterest[slot] = "";
						}
					}
				}
			}
			/* 已死亡头衔兜底: 防 npcNamed 重建/其他系统重置 title */
			if (V.adian._hasKilled && Array.isArray(V.NPCNameList)) {
				const ki = V.NPCNameList.indexOf(V.adian._hasKilled);
				if (ki !== -1 && V.NPCName[ki] && V.NPCName[ki].title !== "已死亡") V.NPCName[ki].title = "已死亡";
			}

			/* ---- 八补、暗-D 囚禁线 pending: rage>=90 时记下当天; 必须跨天后(第二天起)
			   玩家进入 Bedroom/Sea Platform Interior/Eden Cabin 时由 <<adianKidnapCheck>>
			   widget 拦截跳转 Adian Kidnap(widget 内 <<goto>> 是渲染期标准做法,
			   JS 里 goto 不安全故不在此执行)。rage 跌回90以下即撤销 pending(悬崖勒马)。 */
			if (!V.adian._imprisoned && !V.adian._escapedOnce && !V.adian._inHospital &&
				!V.adian._reported && !V.adian._stockholmEnd) {
				if ((V.adian.rage || 0) >= 90) {
					if (typeof V.adian._kidnapPendingDay !== "number") V.adian._kidnapPendingDay = Time.days;
				} else if (typeof V.adian._kidnapPendingDay === "number") {
					delete V.adian._kidnapPendingDay;
				}
			}
		}
	} catch (e) {}

	/* ---- 九、暗-D 追捕掷骰(逃脱后7天内, 未报案) ----
	   每天首次导航递增概率(15%起步 +5%/天, 上限50%), 掷中后当天 _huntEvent=1,
	   adianStalkBlock 渲染红色追捕链接 → Adian Recapture。
	   超时外出(_overdue)也直接标记 _huntEvent=1。 */
	try {
		if (V.adian && V.adian._escapedOnce === 1 && !V.adian._imprisoned &&
			!V.adian._inHospital && V.adian._reported !== 1 &&
			typeof Time !== "undefined" && typeof Time.days === "number") {
			if (V.adian._huntRollDay !== Time.days) {
				V.adian._huntRollDay = Time.days;
				const daysSince = Time.days - (V.adian._escapeDay || 0);
				if (daysSince <= 7) {
					const prob = Math.min(15 + daysSince * 5, 50);
					if (Math.random() * 100 < prob) {
						V.adian._huntEvent = 1;
						V.adian._huntEventDay = Time.days;
					} else {
						V.adian._huntEvent = 0;
					}
				} else {
					/* 7天后若仍未报案, 阿电每天50%概率继续追捕 */
					if (Math.random() * 100 < 50) {
						V.adian._huntEvent = 1;
						V.adian._huntEventDay = Time.days;
					} else {
						V.adian._huntEvent = 0;
					}
				}
			}
			/* 超时外出直接触发追捕(当天) */
			if (V.adian._out === 1 && V.adian._overdue === 1) {
				V.adian._huntEvent = 1;
				V.adian._huntEventDay = Time.days;
			}
		}
	} catch (e) {}

	if (typeof initCNPC === "function") {
		try { initCNPC(); } catch (e) {}
	}
	/* ---- 六补、C.npc 重建: 修复 C.npc["阿电"] 取错对象 + 新游戏开局报错 ----
	   ★问题1: 原版 initCNPC(本体 53503 行) 为 setup.NPCNameList 里每个名字创建
	   C.npc[name] getter, getter 内部用 setup.NPCNameList.indexOf(name) 取
	   V.NPCName[index]。但 V.NPCNameList 的实际顺序可能与 setup.NPCNameList
	   不一致(旧档已有 33+ NPC、其他 mod push 了 NPC、或 npcNamed 重建顺序差异),
	   导致 setup.NPCNameList.indexOf("阿电")=32 但阿电实际在 V.NPCNameList 的
	   index 不是 32, C.npc["阿电"] 取到 V.NPCName[32]=别的 NPC 对象或 undefined。
	   ★问题2(2026-09-23 修复): 旧版基于 V.NPCNameList 重建 C.npc, 但 :passageinit
	   跑在 Start passage 渲染前, 此时 V.NPCNameList 可能是空/undefined(首次启动),
	   C.npc 被重建为空对象。随后 npcNamed 设 V.NPCNameList=setup.NPCNameList,
	   npcPregnancyUpdater 遍历新 V.NPCNameList 访问 C.npc[name].pregnancy, 但
	   C.npc 是空对象无 getter, 返回 undefined → 'Cannot read properties of
	   undefined (reading pregnancy)' 报错。
	   ★修复: 基于 setup.NPCNameList(静态数组, 规则10 已含阿电) 重建 C.npc, 不依赖
	   运行时 V.NPCNameList。getter 内部仍用 V.NPCNameList.indexOf(name) 动态查找,
	   顺序无关且 npcNamed 设 V.NPCNameList 后能返回正确对象。getter 对 V.NPCNameList
	   为空或 name 不在列表时返回 undefined(与原版 initCNPC 行为一致), npcPregnancyUpdater
	   在 npcNamed 之后跑, 此时 V.NPCNameList 已就绪, 不会触发 undefined 分支。 */
	try {
		const fixedCNPC = {};
		const list = (Array.isArray(setup.NPCNameList) ? setup.NPCNameList : []);
		for (const name of list) {
			Object.defineProperty(fixedCNPC, name, {
				get() {
					const arr = V.NPCNameList;
					if (!Array.isArray(arr)) return undefined;
					const idx = arr.indexOf(name);
					return idx >= 0 ? V.NPCName[idx] : undefined;
				},
				set(val) {
					const arr = V.NPCNameList;
					if (Array.isArray(arr)) {
						const idx = arr.indexOf(name);
						if (idx >= 0 && Array.isArray(V.NPCName)) V.NPCName[idx] = val;
					}
				},
				configurable: true,
				enumerable: true,
			});
			}
			C.npc = fixedCNPC;
		} catch (e) {}

		/* ---- 十二、手机系统: 号码同步 + 阿电被动来电每日掷骰 ----
		   a) _hasNumber 与通讯录 Contacts.adian.known 双向兜底(送手机/交换号码两 passage
		      都会同时置位, 此处防旧档/漏设导致通讯录不显示阿电)。
		   b) 拥有手机且已存阿电号码后, 每天首次导航掷骰:
		      - rage>=30: 20%概率接到质问电话
		      - love>=60: 15%概率接到闲聊电话
		      用 _phoneCallDay 防一天多次。 */
		try {
			if (V.Phone && V.Phone.Owned && Array.isArray(V.Phone.Contacts)) {
				const _ac = V.Phone.Contacts.find(c => c && c.id === "adian");
				if (V.adian && V.adian._hasNumber === 1) {
					if (_ac) _ac.known = true;
				} else if (_ac && _ac.known) {
					if (V.adian) V.adian._hasNumber = 1;
				}
			}
			if (V.Phone && V.Phone.Owned && V.adian_met === 1 && V.adian &&
				V.adian._hasNumber === 1 && V.Phone.Durability > 0 &&
				typeof Time !== "undefined" && typeof Time.days === "number") {
				if (V.adian._phoneCallDay !== Time.days) {
					const _rage = V.adian.rage || 0;
					const _love = V.adian.love || 0;
					if (_rage >= 30 && Math.random() < 0.20) {
						V.Phone._incomingCall = "adian_jealous";
						V.adian._phoneCallDay = Time.days;
					} else if (_love >= 60 && Math.random() < 0.15) {
						V.Phone._incomingCall = "adian_chat";
						V.adian._phoneCallDay = Time.days;
					}
				}
			}
		} catch (e) {}
	});

/* ==========================================================================
   十一、NPC 对玩家的称呼(性别/转化细微变化)
   --------------------------------------------------------------------------
   setup.adianCallWord() 返回称呼词, 供 <<adianCall>> widget 输出:
   优先按可见转化特征: 小恶魔/小天使/小鸟/小猫/小狼/小狐狸/小牛;
   无可见特征则按玩家代词($pronoun): m=小子 / f=小姑娘 / i|n|t=怪家伙。
   转化判定: $transformationParts.<种族>.<部位> 值非 "disabled"/"hidden"
   即为可见(本体 L66488-66494 同规则); 计数完全体($cat/$fox/$wolfgirl/
   $cow/$harpy/$angel/$demon >= 6)也生效——部件全隐藏的低调玩家,
   NPC 仍能从气味/气质认出来。
   ========================================================================== */
setup.adianCallWord = function () {
	try {
		const V = State.variables;
		const T = V.transformationParts || {};
		const vis = function (sp, slots) {
			const o = T[sp];
			if (!o) return false;
			return slots.some(function (s) { return o[s] && o[s] !== "disabled" && o[s] !== "hidden"; });
		};
		const cnt = function (v) { return typeof v === "number" && v >= 6; };
		if (vis("demon", ["horns", "wings", "tail"]) || cnt(V.demon)) return "小恶魔";
		if (vis("angel", ["halo", "wings"]) || vis("fallenAngel", ["halo", "wings"]) || cnt(V.angel)) return "小天使";
		if (vis("bird", ["wings", "tail", "plumage"]) || cnt(V.harpy)) return "小鸟";
		if (vis("cat", ["ears", "tail"]) || cnt(V.cat)) return "小猫";
		if (vis("wolf", ["ears", "tail"]) || cnt(V.wolfgirl)) return "小狼";
		if (vis("fox", ["ears", "tail"]) || cnt(V.fox)) return "小狐狸";
		if (vis("cow", ["ears", "horns", "tail"]) || cnt(V.cow)) return "小牛";
		switch (V.pronoun) {
			case "m": return "小子";
			case "f": return "小姑娘";
			default: return "怪家伙";
		}
	} catch (e) {
		return "你这家伙";
	}
};

/* ==========================================================================
   十五、阿电代词适配(性别设置联动)
   开局/设置里的"已命名角色设置"可把阿电设为女性(pronoun "f"), 但 mod 剧情
   文本写死了"他"。此处对【文本中"他"全部指阿电】的 passage 做渲染后替换:
   他→她、少年→少女。以下 passaged 文本含其他男性NPC(警察/博士/死者闪回/
   摊主/鱼贩), 不在白名单内, 保持原样: Adian Police *, Adian Hospital Doctor,
   Adian Flashback, Adian Grave, Adian Walk Bully, Adian Walk * Encounter,
   Adian Hall Peek, Canteen Lunch Adian, Hospital Ghost Doctor, New Game Plus,
   indianStall/hedgefunds/seaplatform 全部。
   ========================================================================== */
setup.adianIsFemale = function () {
	try {
		const V = State.variables;
		const idx = V.NPCNameList ? V.NPCNameList.indexOf("阿电") : -1;
		return idx >= 0 && V.NPCName[idx] && V.NPCName[idx].pronoun === "f";
	} catch (e) { return false; }
};
setup.adianPronounPassages = new Set([
	/* modcontent.twee —— 纯阿电场景 */
	"Adian Room", "Adian Player Confession", "Adian Study", "Adian Confession Accept",
	"Adian Confession Event", "Adian Confession Friend", "Adian Confession Reject",
	"Adian Confess", "Adian Play Chess", "Adian Play Pillow", "Adian Play Gate",
	"Adian Play Games", "Adian Play Cards", "Adian Play Movie", "Adian Play Menu",
	"Adian Walk Park", "Adian Walk Beach", "Adian Walk Cafe", "Adian Walk",
	"Adian Walk to School", "Adian Chat", "Adian Lunch", "Pet Adian", "Adian Breakup",
	"Adian Call Widget", "Clean Room",
	/* stalking.twee —— 跟踪/嫉妒事件(死者吊唁 Adian Grave 除外) */
	"Adian Stalk Event", "Adian Stalk Event Result", "Adian Jealous Event", "Adian Jealous Event Result",
	/* adiankidnap.twee —— 囚禁/医院探视(警察与医生 passage 除外) */
	"Adian Kidnap", "Adian Basement", "Adian Basement Check", "Adian Captive Care",
	"Adian Captive Talk", "Adian Captive Defy", "Adian Picklock", "Adian Ask Out",
	"Adian Return", "Adian Recapture", "Adian Hospital Talk", "Adian Hospital Visit",
	"Adian Hospital Sit", "Adian Room Empty", "Adian Evidence Search",
	/* adianencounter.twee / adianroleplay.twee —— 遭遇战与角色扮演, 均纯阿电 */
	"Adian Encounter", "Adian Encounter Stop", "Adian Encounter Climax", "Adian Encounter Intro",
	"Adian RP Nurse", "Adian RP Master", "Adian RP Shop", "Adian RP To Encounter", "Adian RP Menu",
]);
$(document).on(":passagerender", function (ev) {
	try {
		if (!setup.adianIsFemale()) return;
		const name = (typeof passage === "function" ? passage() : "") || "";
		if (!setup.adianPronounPassages.has(name)) return;
		const root = ev.content && (ev.content[0] || ev.content);
		if (!root || !root.querySelectorAll) return;
		const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
		const targets = [];
		let node;
		while ((node = walker.nextNode())) {
			if (node.nodeValue.indexOf("他") !== -1 || node.nodeValue.indexOf("少年") !== -1) {
				targets.push(node);
			}
		}
		targets.forEach(function (t) {
			t.nodeValue = t.nodeValue.replace(/他/g, "她").replace(/少年/g, "少女");
		});
	} catch (e) {}
});
/* ==========================================================================
   十四、作弊面板阿电状态辅助(boot.json 规则20 调用)
   setup.cheatAdian(attr, value): 阿电未注册时自动注册(含C.npc重建兜底),
   然后写入指定属性。返回值恒为 true, 用于 numberStepper callback。
   ========================================================================== */
/* 中文代词映射: 按本体 generatePronouns 的键, 值本地化为中文 */
setup.adianPronounsFor = function (pro) {
	switch (pro) {
		case "f": return { he: "她", He: "她", his: "她的", hers: "她的", him: "她", himself: "她自己", man: "少女", boy: "少女", men: "少女们" };
		case "i": return { he: "它", He: "它", his: "它的", hers: "它的", him: "它", himself: "它自己", man: "少年", boy: "少年", men: "少年们" };
		case "n":
		case "t": return { he: "TA", He: "TA", his: "TA的", hers: "TA的", him: "TA", himself: "TA自己", man: "少年", boy: "少年", men: "少年们" };
		default:  return { he: "他", He: "他", his: "他的", hers: "他的", him: "他", himself: "他自己", man: "少年", boy: "少年", men: "少年们" };
	}
};
setup.cheatAdian = function (attr, value) {
	try {
		const V = State.variables;
		if (!V.NPCNameList.includes("阿电")) {
			/* 自动注册: 名字+标题 */
			V.NPCNameList.push("阿电");
			V.NPCName = V.NPCName || [];
			V.NPCName.push({
				"nam": "阿电", "title": "阿电", "displayname": "阿电",
				"description": "一个总带着点局促的年轻人",
				"pronoun": "m", "gender": "m", "age": "teen", "teen": 1, "adult": 0,
				"init": 1, "intro": 1, "love": 0, "lust": 0, "dom": 0, "rage": 0,
				"trauma": 0, "chastity": { "penis": "", "vagina": "", "anus": "" },
				"virginity": { "vaginal": true, "penile": true },
				"pronouns": setup.adianPronounsFor("m")
			});
		}
		const idx = V.NPCNameList.indexOf("阿电");
		if (idx >= 0 && V.NPCName[idx]) {
			V.NPCName[idx][attr] = value;
		}
	} catch (e) {}
	return true;
};

/* ==========================================================================
   十、死者封禁 + 悲伤特质闪回(暗-B 2b 改写)
   --------------------------------------------------------------------------
   10a. 包装 <<runeventpool>> 宏: 抽取前把事件名含死者关键词的事件从临时池
        中剔除(死者不再有任何随机剧情), 过滤后为空则保留原池, 强制 override
        到死者事件时一并撤销。
   10b. prehistory 回忆闪回掷骰(不再硬封路): 获得"悲伤"特质后, 进入逝者
        私域(DEAD_PASSAGE_RULES 前缀, 30%)或其会出现的公共场所(7%)时,
        每天最多触发一次, 重定向到 :: Adian Flashback, 该 passage 结算大量
        负面效果后动态返回原 passage。杀人当天由授予逻辑压制不闪回。
   ========================================================================== */
(function () {
	try {
		const DEAD_EVENT_KEYWORDS = {
			"Robin": ["robin"],
			"Whitney": ["whitney"],
			"Kylar": ["kylar"],
			"Sydney": ["sydney"],
			"Alex": ["alex"],
			"Avery": ["avery"],
			"Eden": ["eden"],
			"Great Hawk": ["hawk"],
			"Black Wolf": ["blackwolf", "wolfcave"],
		};
		const DEAD_PASSAGE_RULES = {
			"Robin":      { prefixes: ["Robin"] },
			"Whitney":    { prefixes: ["Whitney"] },
			"Kylar":      { prefixes: ["Kylar"] },
			"Sydney":     { prefixes: ["Sydney"] },
			/* "Alex"=礼物/住所/子事件; "Farm"=整个农场; 排除 Farmland(公共街景) */
			"Alex":       { prefixes: ["Alex", "Farm"], excludes: ["Farmland"] },
			"Avery":      { prefixes: ["Avery"] },
			"Eden":       { prefixes: ["Eden"] },
			"Great Hawk": { prefixes: ["Bird Tower"] },
			"Black Wolf": { prefixes: ["Wolf Cave"] },
		};
		/* 逝者生前会出现的公共场所(低概率闪回), 避免在衣柜/睡眠等系统
		   passage 触发。Farmland 是通往森林的公共道路, 列入(农场主 Alex)。 */
		const COMMON_FLASHBACK = /^(School|Classroom|English Class|Maths Class|History Class|Science Class|Geography Class|Library|Canteen|Corridor|Hallway|School Front Courtyard|Playground|Gym|Shower Room|Domus Street|High Street|Park|Beach|Market|Town|Bus Stop|Shopping Centre|Cafe|Cinema|Amusement|Forest|Farmland)/;

		/* 10a. runeventpool 宏包装(幂等) */
		if (typeof Macro !== "undefined" && Macro.get) {
			const rep = Macro.get("runeventpool");
			if (rep && rep.handler && !rep._adianDeadPatch) {
				const origHandler = rep.handler;
				rep._adianDeadPatch = true;
				rep.handler = function () {
					try {
						const V2 = State.variables;
						const dead = V2.adian && V2.adian._hasKilled;
						if (dead && DEAD_EVENT_KEYWORDS[dead]) {
							const kws = DEAD_EVENT_KEYWORDS[dead];
							const pool = State.temporary.eventpool;
							if (Array.isArray(pool) && pool.length) {
								const kept = pool.filter(function (e) {
									if (!e || !e.name) return true; /* 无名内联事件保留 */
									const n = String(e.name).toLowerCase();
									return !kws.some(function (k) { return n.indexOf(k) >= 0; });
								});
								if (kept.length) State.temporary.eventpool = kept;
							}
							/* $eventPoolOverride 强指死者事件 → 撤销, 回落随机池 */
							if (V2.eventPoolOverride) {
								const ovName = V2.eventPoolOverride.name || V2.eventPoolOverride;
								const ov = String(ovName).toLowerCase();
								if (kws.some(function (k) { return ov.indexOf(k) >= 0; })) {
									delete V2.eventPoolOverride;
								}
							}
						}
					} catch (e) {}
					return origHandler.apply(this, arguments);
				};
			}
		}

		/* 10b. prehistory 回忆闪回掷骰(幂等) */
		if (typeof prehistory !== "undefined" && prehistory && !prehistory.adianDeadGuard) {
			prehistory.adianDeadGuard = function (title) {
				try {
					if (title === "Adian Flashback" || title === "Adian Grave") return;
					const V2 = State.variables;
					if (!V2.adian || !V2.adian._hasKilled) return;
					if (!V2.feats || !V2.feats.currentSave || !V2.feats.currentSave["悼亡"]) return;
					if (typeof Time === "undefined" || typeof Time.days !== "number") return;
					/* 每天最多一次重闪回 */
					if (V2.adian._lastFlashbackDay === Time.days) return;

					const rule = DEAD_PASSAGE_RULES[V2.adian._hasKilled];
					let inDomain = false;
					if (rule && rule.excludes.indexOf(title) < 0) {
						inDomain = rule.prefixes.some(function (p) { return title === p || title.indexOf(p) === 0; });
					}
					const inCommon = !inDomain && COMMON_FLASHBACK.test(title);
					if (!inDomain && !inCommon) return;

					/* 私域 30% / 公共场所 7%; 随距死亡天数衰减, 下限 10%/3% */
					let chance = inDomain ? 0.30 : 0.07;
					const daysAfter = Time.days - (V2.adian._killDay || Time.days);
					chance = Math.max(inDomain ? 0.10 : 0.03, chance - daysAfter * 0.005);
					if (Math.random() < chance) {
						V2.adian._flashbackReturn = title;
						V2.adian._flashbackDomain = inDomain ? 1 : 0;
						V2.adian._lastFlashbackDay = Time.days;
						Engine.play("Adian Flashback", { override: true });
					}
				} catch (e) {}
			};
		}
	} catch (e) {}
})();

/* ==========================================================================
   TODO — 未完成功能清单
   --------------------------------------------------------------------------
   【嫉妒暗线变量初始化 — 暗-A~D 实装时需在 :passageinit 中补缺】
   ☐ $adian._stalkText / _stalkEventCooldown — 跟踪期(rage 50-59)
   ☐ $adian._hasKilled / _killDay           — 杀人事件(rage 60-99)
   ☐ $adian._imprisoned / _imprisonDay       — 囚禁(rage 100)
   ☐ $adian._stockholm / _stockholmEnd       — 斯德哥尔摩综合征
   ☐ $adian._captiveTrust / _freedomLevel    — 囚禁期信任+自由活动
   ☐ $adian._outHours / _overdue / _overdueCount — 外出计时
   ☐ $adian._evidence / _evidenceFound       — 囚禁期证据收集
   ☐ $adian._reported / _policeAction        — 警察局报案线
   ☐ $adian._rescuedByDoctor / _inHospital    — 异瞳医生介入
   ☐ $adian._escapedOnce / _huntCooldown     — 逃跑+追捕
   ☐ $ngplus_trigger="adian"                 — 硬坏结局第三种仪式途径

   【扩展功能 — 计划文档优先级】
   ☐ 信件/纸条系统: 回安全屋时检测 $adian.love>=30 后概率触发, 需在
     :passageinit 中初始化 $adian._letter 相关变量
   ☐ 嫉妒具象化: 玩家与别的NPC亲密时触发, 需在 :passageinit 中追踪
     玩家 passage 判断是否与特定NPC互动, 设 $adian._jealousyEvent
   ☐ 阿电生病: :passageinit 中检查 $adian._sickCooldown, 恶劣天气3%概率
   ☐ 考试周: :passageinit 中检查 Time.days 是否在考试周, 设 $adian._examWeek
   ========================================================================== */
