/* ==========================================================================
   MyFirstMod - 周目+ / 硬坏结局 (ngplus.js)
   --------------------------------------------------------------------------
   功能: 硬坏结局轮回系统——把玩家被爱人杀死的一世的身体/容貌/技能/成就快照,
         重启游戏后合并带回新周目, 与官方"软坏结局"对立
   方法: localStorage 存快照(key=myMod_ngplus_snapshot), Engine.restart() 清
         SugarCube state 回主菜单; :passageinit 监听检测快照, 新档进世界后
         合并 player/transformationParts/feats/skills 并删除快照(一次性)
   依赖: 对应 passage 在 moduel/ngplus.twee; 自包含, 只依赖游戏全局
         (V/Engine/localStorage/loadFeats), 不引用 modscript.js
   --------------------------------------------------------------------------
   休眠说明: ngplus.twee 没有任何常驻入口链接, 正常游玩进不去; 测试时作弊执行
   <<goto "New Game Plus">> 即可。
   定位: 与官方"软坏结局"(<<badEndTracking>> 那一类: 精神病院/地下农场/地牢/
   狼穴/Eden/矿坑/监狱/收容所)对立——软坏结局里玩家被囚禁改造但世界延续、
   关系还在; 硬坏结局里这一世彻底终结, 金钱·关系·剧情全部湮灭, 但身体(转化)·
   容貌·技能·成就随轮回带走。
   ==========================================================================
   一、常量与工具 (NGKEY/CYCLEKEY/SKILL_KEYS/deepClone)
   二、NgPlus.snapshotAndRestart (第1步: 旧档快照并重启)
   三、NgPlus.restoreIfPending (第3步: 新档恢复并删除快照)
   四、:passageinit 监听 (触发恢复)
   ========================================================================== */
(function () {
	const NGKEY = "myMod_ngplus_snapshot";
	/* 轮回次数: 单独存 localStorage(不随 SugarCube 重启清空), 每次坠入轮回 +1。
	   关口的神秘医生据此嘲讽"第几次了/又回来攻略谁"; 同时随快照带进新档
	   V.ngplusCycle, 供 twee 读取。 */
	const CYCLEKEY = "myMod_ngplus_cycles";
	/* 要带回新周目的技能/属性顶层变量(都是 V 上的数字)。
	   快照时只拷当前档里确为 number 的键; 名字因版本不符/不存在会被
	   自动跳过, 不会报错, 可放心按需增删。
	   physiquesize 必须连带: 它是 $physique 的上限, 不带回会被新档默认
	   上限 clamp 掉高体魄。 */
	const SKILL_KEYS = [
		"physique", "physiquesize", "physiqueuse", "skulduggery",
		"tending", "housekeeping", "danceskill",
		"english", "science", "math", "history", "art", "music",
		"swimming", "willpower"
	];
	function deepClone(o) { try { return JSON.parse(JSON.stringify(o)); } catch (e) { return o; } }

	window.NgPlus = {
		/* 二、snapshotAndRestart —— 第1步: 旧档里调用(ngplus.twee 的按钮)。快照后立即重启。 */
		snapshotAndRestart: function () {
			try {
				const data = {
					version: 1,
					player: deepClone(V.player),
					transformationParts: deepClone(V.transformationParts),
					feats: {
						currentSave: (V.feats && V.feats.currentSave) ? deepClone(V.feats.currentSave) : {}
					},
					skills: {}
				};
				SKILL_KEYS.forEach(function (k) {
					if (typeof V[k] === "number") data.skills[k] = V[k];
				});
				/* 轮回计数 +1 并持久化(独立于快照, 重启不丢) */
				let cycles = parseInt(localStorage.getItem(CYCLEKEY) || "0", 10);
				if (!Number.isFinite(cycles)) cycles = 0;
				cycles += 1;
				localStorage.setItem(CYCLEKEY, String(cycles));
				data.cycle = cycles;
				localStorage.setItem(NGKEY, JSON.stringify(data));
				if (typeof Engine !== "undefined" && Engine.restart) {
					Engine.restart();
				} else {
					console.error("NgPlus: Engine.restart 不可用");
				}
			} catch (e) {
				console.error("NgPlus snapshot failed:", e);
			}
		},

		/* 三、restoreIfPending —— 第3步: :passageinit 里调用。新档进世界后一次性恢复。 */
		restoreIfPending: function () {
			try {
				const raw = localStorage.getItem(NGKEY);
				if (!raw) return;
				/* 必须等游戏把身体/转化/特质对象初始化好; 且跳过主菜单
				   Start passage(那时玩家还在设置界面, 点 Start Game 后
				   才离开 Start, 此时外貌已定型可安全覆盖)。 */
				if (!(V.options && V.player && V.player.sex && V.transformationParts && V.feats)) return;
				if (V.passage === "Start") return;

				const data = JSON.parse(raw);
				if (data.player) Object.assign(V.player, data.player);
				if (data.transformationParts) V.transformationParts = deepClone(data.transformationParts);
				if (data.feats && data.feats.currentSave) {
					V.feats.currentSave = Object.assign({}, V.feats.currentSave || {}, data.feats.currentSave);
					try { if (typeof loadFeats === "function") loadFeats(V.feats.currentSave); } catch (e) {}
				}
				if (data.skills) {
					Object.keys(data.skills).forEach(function (k) {
						if (typeof data.skills[k] === "number") V[k] = data.skills[k];
					});
				}
				/* 跳过新手骚扰/战斗教程(游戏判定 $tutorial is 0 才触发教学) */
				V.tutorial = 1;
				V.ngplusCarried = 1;
				/* 轮回次数带进新档: 优先快照里的值, 兜底读持久计数 */
				let carriedCycle = (typeof data.cycle === "number") ? data.cycle
					: (parseInt(localStorage.getItem(CYCLEKEY) || "0", 10) || 0);
				V.ngplusCycle = carriedCycle;
				localStorage.removeItem(NGKEY);
				console.log("NgPlus: 二周目继承完成, 第 " + carriedCycle + " 次轮回");
			} catch (e) {
				console.error("NgPlus restore failed:", e);
			}
		}
	};
})();

/* 四、:passageinit 监听 —— 硬坏结局继承恢复: 重启后的新档进入世界时, 把
   快照里的身体/转化/技能/特质合并回来。无快照时直接返回, 正常游戏零影响。 */
$(document).on(':passageinit', function () {
	try { window.NgPlus.restoreIfPending(); } catch (e) {}
});

/* ==========================================================================
   TODO — 未完成功能清单
   --------------------------------------------------------------------------
   【$ngplus_trigger="adian" — 阿电囚禁线硬坏结局途径】
   ☐ 暗-D 实装后, 在 New Game Plus passage 的 $ngplus_trigger 分支中
     加 "adian" case: "是阿电把你做成了标本, 永远摆在他身边"
   ☐ 触发条件: rage>=100 + 被囚禁过 + 逃跑被抓 + $submissive<=850(抵抗倾向)
   ☐ 快照内容不变(身体/技能/特质), 但关口医生的台词需加 $ngplus_trigger=="adian"
     专属分支: "被自己的小男朋友做成标本, 也挺有收藏价值的"

   【快照扩展 — 以后可按需增减】
   ☐ 可考虑: 把 $adian 相关标记(如 _hasKilled)随快照带到新周目, 让二周目
     男鬼医生能提到"你上一世被那个叫阿电的小子关起来了"——需在 SKILL_KEYS
     之外新增自定义快照字段, 不能用现有的 skills 字段(那是纯数字)
   ☐ 可考虑: 随快照带 $ngplusCycle 到新周目后, 在 :passageinit 中根据
     周目数解锁不同内容(如: 3周目起医院出现新选项)
   ========================================================================== */
