/* ==========================================================================
   平台钓鱼系统(配合 moduel/hedgefunds.twee)
   反应式小游戏: <<pass>> 推进时间, <<timed>> 回调触发(浮标沉下)时记录
   $fishing._biteMs, "拉杆"后由 setup.fishingResolve() 用 Date.now() 差值
   判定中鱼区间(1~3秒)。
   ★_biteMs 必须在 timed 回调里写, 不能在拉杆链接里写——否则结算与点击
   几乎同一时刻, 差值恒为0, 永远判定"太早"。

   数据结构(参考 fish.html 的重量随机系统):
   $fishing.catch[鱼种] = { count: 条数, weight: 总重量(单位:克×100) }
   $fishing.achieve[鱼种] = 最大单条重量(克×100, 图鉴用)
   重量显示时除以100得 kg, 精确到小数点后两位。

   渔获进 $fishing.catch, 去市场(Connudatus Markets)的
   <<adianFishSellLink>>(boot.json 规则27 注入) 批量出售。
   ========================================================================== */
setup.fishingTable = [
	{ name: "沙丁鱼",           min: 0.00, max: 0.40, price: 3,  wMin: 15,  wMax: 120,  txt: "银白色的小鱼，成群结队地在近海游弋。" },
	{ name: "鲭鱼",             min: 0.40, max: 0.65, price: 6,  wMin: 30,  wMax: 250,  txt: "背部有深蓝色条纹，肉质紧实。" },
	{ name: "比目鱼",           min: 0.65, max: 0.82, price: 10, wMin: 50,  wMax: 400,  txt: "扁平的身体贴着海底滑行，两只眼睛长在同一侧。" },
	{ name: "海鲈鱼",           min: 0.82, max: 0.93, price: 16, wMin: 100, wMax: 800,  txt: "凶猛的掠食者，咬钩时力道十足。" },
	{ name: "金枪鱼",           min: 0.93, max: 0.98, price: 35, wMin: 200, wMax: 2000, txt: "体型硕大，游速极快，是远海渔民梦寐以求的战利品。" },
	{ name: "发光的浮游生物群", min: 0.98, max: 1.00, price: 80, wMin: 1,   wMax: 5,    txt: "一网下去捞到的不是鱼，而是一团幽幽发亮的浮游生物。据说有人专门收购这种东西。" },
];
setup.fishingResolve = function () {
	const V = State.variables;
	if (!V.fishing) V.fishing = { catch: {}, achieve: {} };
	if (!V.fishing.catch) V.fishing.catch = {};
	if (!V.fishing.achieve) V.fishing.achieve = {};
	/* 旧存档迁移: 旧格式 $fishing.catch[鱼种]=数量(纯数字),
	   新格式={count,weight}。检测到数字时自动补重量。 */
	for (const k in V.fishing.catch) {
		if (typeof V.fishing.catch[k] === 'number') {
			const n = V.fishing.catch[k];
			const fd = setup.fishingTable.find(f => f.name === k);
			const avgW = fd ? Math.round((fd.wMin + fd.wMax) / 2) : 100;
			V.fishing.catch[k] = { count: n, weight: n * avgW };
		}
	}
	const now = Date.now();
	const bite = V.fishing._biteMs || 0;
	const elapsed = bite ? (now - bite) / 1000 : 99; // 秒; 无咬钩记录(防直链)按太晚处理
	V.fishing._biteMs = 0;
	let result;
	if (elapsed >= 1 && elapsed <= 3) {
		// 命中窗口: 掷鱼
		const roll = Math.random();
		const fish = setup.fishingTable.find(f => roll >= f.min && roll < f.max) || setup.fishingTable[0];
		const key = fish.name;
		// 重量随机(wMin~wMax, 单位:克×100)
		const weight = Math.floor(Math.random() * (fish.wMax - fish.wMin + 1)) + fish.wMin;
		// 写入背包
		if (!V.fishing.catch[key]) V.fishing.catch[key] = { count: 0, weight: 0 };
		V.fishing.catch[key].count += 1;
		V.fishing.catch[key].weight += weight;
		// 更新图鉴(只记超过旧记录的)
		let newRecord = false;
		if (!V.fishing.achieve[key] || weight > V.fishing.achieve[key]) {
			V.fishing.achieve[key] = weight;
			newRecord = true;
		}
		result = { ok: true, fish: fish.name, price: fish.price, weight: weight, kg: (weight / 100).toFixed(2), newRecord: newRecord, elapsed: elapsed.toFixed(2) };
	} else if (elapsed < 1) {
		result = { ok: false, reason: "太早", detail: "鱼还没咬钩，你一提竿它就跑了。", elapsed: elapsed.toFixed(2) };
	} else {
		result = { ok: false, reason: "太晚", detail: "浮标已经沉下去又浮起来了，鱼饵被吃光了。", elapsed: elapsed.toFixed(2) };
	}
	return result;
};

/* ---- 弹窗内容生成(纯JS, 避免 wikiPassage 渲染自定义 passage 触发 DoL 钩子报错) ---- */

/* 渔获弹窗: 拉杆后调用, 返回 HTML 字符串 */
setup.fishingResultHtml = function () {
	const r = setup.fishingResolve();
	let html = '';
	if (r.ok) {
		html += '你手腕一抖，竿尖弯成一道漂亮的弧线——<br><br>';
		html += '<span class="green bold">钓到了！一条 ' + r.fish + '！</span><br><br>';
		html += '重量：' + r.kg + ' kg';
		if (r.newRecord) html += '<br><span style="color:gold">【图鉴已更新】</span>';
		html += '<br><br>它在你手里扑腾着，鳞片在太阳底下闪了一下。你把它丢进脚边的鱼篓里，听见"咚"的一声闷响。';
	} else {
		html += '你猛地一提竿——<br><br>';
		html += '<span class="red">' + r.detail + '</span><br><br>';
		html += '鱼线空荡荡地晃着，浮标重新浮在水面上，像什么都没发生过。';
	}
	return html;
};

/* 鱼篓弹窗 */
setup.fishingBagHtml = function () {
	const V = State.variables;
	if (!V.fishing || !V.fishing.catch) return '鱼篓空空如也。';
	/* 旧存档迁移 */
	for (const k in V.fishing.catch) {
		if (typeof V.fishing.catch[k] === 'number') {
			const n = V.fishing.catch[k];
			const fd = setup.fishingTable.find(f => f.name === k);
			const avgW = fd ? Math.round((fd.wMin + fd.wMax) / 2) : 100;
			V.fishing.catch[k] = { count: n, weight: n * avgW };
		}
	}
	const entries = Object.entries(V.fishing.catch).filter(([, v]) => v.count > 0);
	if (!entries.length) return '鱼篓空空如也。';
	let html = '', totalCount = 0, totalWeight = 0;
	for (const [name, v] of entries) {
		const kg = (v.weight / 100).toFixed(2);
		html += name + '：' + v.count + ' 条，共 ' + kg + ' kg<br>';
		totalCount += v.count;
		totalWeight += v.weight;
	}
	html += '<br>合计：' + totalCount + ' 条，' + (totalWeight / 100).toFixed(2) + ' kg';
	return html;
};

/* 图鉴弹窗 */
setup.fishingDexHtml = function () {
	const V = State.variables;
	if (!V.fishing) V.fishing = { catch: {}, achieve: {} };
	if (!V.fishing.achieve) V.fishing.achieve = {};
	let html = '';
	for (const f of setup.fishingTable) {
		const rec = V.fishing.achieve[f.name];
		if (rec) {
			html += '<span class="green">' + f.name + '</span><br>';
			html += '最大记录：' + (rec / 100).toFixed(2) + ' kg<br>';
			html += '<span class="grey">' + f.txt + '</span><br>';
		} else {
			html += '<span class="grey">???<br>尚未钓到</span><br>';
		}
		html += '<br>';
	}
	return html;
};
