/* MyFirstMod 手机系统核心 JS
   参考 SmartPhone main.js 架构但独立实现
   功能：右下角固定手机图标 + 点击展开/收起 + APP切换 + 状态管理
        多款手机 + 耐久损耗/修理 + 弹窗内短信聊天 */

window.PhoneMod = {};

// ==================== 手机型号表 ====================
// id: 型号标识(存档用)  name: 显示名  price: 便士(£1=100)  dur: 耐久上限  desc: 描述
// gift 为阿电赠送款(非卖品, 店里不出示; 以旧换新时按 £250 档折价)
PhoneMod.PhoneModels = {
	basic:    { id: "basic",    name: "入门智能机", price: 12000, dur: 60,  desc: "屏幕边缘有点厚，胜在便宜耐摔。该有的功能都有。" },
	standard: { id: "standard", name: "智能手机",   price: 25000, dur: 100, desc: "一块大屏的标准智能机，做工扎实，预装了常用软件。" },
	pro:      { id: "pro",      name: "旗舰智能机", price: 48000, dur: 160, desc: "金属中框、高清三摄，店员说它用了都说好。" },
	gift:     { id: "gift",     name: "阿电送的智能机", price: 25000, dur: 100, shop: false, desc: "包装得歪歪扭扭的盒子，是他攒了好久的钱买的。" },
};

// 店售机型列表(供商店 passage 遍历, 自动排除 shop:false 的非卖品)
PhoneMod.getShopModels = function() {
	return Object.values(PhoneMod.PhoneModels).filter(m => m.shop !== false);
};

// ==================== 状态初始化 ====================
// 在 :passagerender 中调用，确保 V.Phone 存在且字段完整
PhoneMod.initState = function() {
	if (typeof V.Phone === "undefined" || V.Phone === null) {
		V.Phone = {
			Owned: false,
			Model: null,            // 当前手机型号 id
			Durability: 0,          // 当前耐久(0 = 损坏)
			CurrentApp: "main",
			CurrentChat: null,      // 信息APP内当前打开的对话对象 id
			_chatInput: "",         // 短信输入框绑定值
			Contacts: [
				{ id: "adian", name: "阿电", known: false, desc: "他总说自己手机不离身" },
				{ id: "robin", name: "罗宾", known: true, desc: "住在隔壁的青梅竹马" },
				{ id: "harper", name: "哈珀", known: false, desc: "南丁格尔街医院的医生" },
				{ id: "whitney", name: "惠特尼", known: false, desc: "学校里的校霸" },
				{ id: "avery", name: "艾弗里", known: false, desc: "出手阔绰的富家子弟" },
				{ id: "kylar", name: "凯拉尔", known: false, desc: "安静得有点吓人的同学" },
				{ id: "sydney", name: "悉尼", known: false, desc: "在教堂帮忙的温柔孩子" },
			],
			Battery: 100,           // 电量 0~100, 0=自动关机
			Stolen: null,           // "combat"=被抢 / "stolen"=被偷 / null=在身边
			Case: false,            // 防摔手机壳(掏夕夕商品), 耐久损耗减半
			_stolenDay: -1,         // 手机丢失的游戏日(失物招领需隔天)
			_theftDay: -1,          // 上次街头被偷判定日(每日一次)
			_flashUsed: 0,          // 本场战斗已用闪光灯次数(每场限2次)
			Messages: [],
			Orders: [],
			Alarms: [],
			Memo: [],
			YeNote: null,        // 小黄书账号数据, 首次打开APP时由 YeNoteMod.ensure() 建立
			Apps: ["contacts", "messages", "shop", "taxi", "alarm", "memo", "commission", "camera", "album", "yenote"],
			_incomingCall: null,
			_phoneCallDay: 0,
			_wasCombat: 0,          // 上一帧是否在战斗(边沿检测, 每场战斗只损耗一次)
			_rainDay: -1,           // 上次因暴雨损耗的游戏日
			ReturnPassage: null,
			ReturnLocation: null,
			ReturnOutside: null,
		};
	}
	// 字段级兜底（存档兼容）
	if (!V.Phone.Contacts) V.Phone.Contacts = [];
	if (!V.Phone.Messages) V.Phone.Messages = [];
	if (!V.Phone.Orders) V.Phone.Orders = [];
	if (!V.Phone.Alarms) V.Phone.Alarms = [];
	if (!V.Phone.Memo) V.Phone.Memo = [];
	if (!V.Phone.Apps) V.Phone.Apps = ["contacts", "messages", "shop", "taxi", "alarm", "memo", "commission", "camera", "album", "yenote"];
	/* 旧档迁移: 约稿APP是后期新增, 老存档的 Apps 数组里没有, 补进去 */
	if (V.Phone.Apps && !V.Phone.Apps.includes("commission")) V.Phone.Apps.push("commission");
	if (typeof V.Phone.CurrentApp === "undefined") V.Phone.CurrentApp = "main";
	if (typeof V.Phone.CurrentChat === "undefined") V.Phone.CurrentChat = null;
	if (typeof V.Phone._chatInput === "undefined") V.Phone._chatInput = "";
	if (typeof V.Phone.Owned === "undefined") V.Phone.Owned = false;
	/* 旧档兼容: 已有手机但没有型号/耐久字段的, 视为标准机全新状态 */
	if (V.Phone.Owned && !V.Phone.Model) {
		V.Phone.Model = "standard";
		V.Phone.Durability = PhoneMod.PhoneModels.standard.dur;
	}
	if (typeof V.Phone.Durability !== "number") V.Phone.Durability = 0;
	/* 电量/丢失/手机壳/闪光灯字段兜底(旧档兼容) */
	if (typeof V.Phone.Battery !== "number" || isNaN(V.Phone.Battery)) V.Phone.Battery = 100;
	if (typeof V.Phone.Stolen === "undefined") V.Phone.Stolen = null;
	if (typeof V.Phone.Case !== "boolean") V.Phone.Case = false;
	if (typeof V.Phone._stolenDay !== "number") V.Phone._stolenDay = -1;
	if (typeof V.Phone._theftDay !== "number") V.Phone._theftDay = -1;
	if (typeof V.Phone._flashUsed !== "number") V.Phone._flashUsed = 0;
	/* 旧档补新联系人(惠特尼/艾弗里/凯拉尔/悉尼) */
	const extraContacts = [
		{ id: "whitney", name: "惠特尼", desc: "学校里的校霸" },
		{ id: "avery", name: "艾弗里", desc: "出手阔绰的富家子弟" },
		{ id: "kylar", name: "凯拉尔", desc: "安静得有点吓人的同学" },
		{ id: "sydney", name: "悉尼", desc: "在教堂帮忙的温柔孩子" },
	];
	/* 旧档补新联系人(惠特尼/艾弗里/凯拉尔/悉尼) */
	extraContacts.forEach(c => {
		if (!V.Phone.Contacts.find(x => x.id === c.id)) {
			V.Phone.Contacts.push({ id: c.id, name: c.name, known: false, desc: c.desc });
		}
	});
	/* 自动解锁: 已在本体认识(见过面)的 NPC 自动加入通讯录。
	   判定: C.npc.XXX.init === 1 (本体统一"已认识"标志) */
	const npcMap = { whitney: "Whitney", avery: "Avery", kylar: "Kylar", sydney: "Sydney" };
	Object.keys(npcMap).forEach(id => {
		try {
			const npcName = npcMap[id];
			if (C.npc[npcName] && C.npc[npcName].init === 1) {
				const c = V.Phone.Contacts.find(x => x.id === id);
				if (c && !c.known) c.known = true;
			}
		} catch (e) {}
	});
};

// ==================== 电量系统 ====================
/* 耗电。reason 仅作备注。电量扣到 0 时手机自动关机(弹窗收起)。
   返回 true 表示这次耗电导致关机。 */
PhoneMod.drainBattery = function(amount, reason) {
	if (!V.Phone || !V.Phone.Owned || V.Phone.Stolen) return false;
	const before = V.Phone.Battery;
	V.Phone.Battery = Math.max(0, V.Phone.Battery - amount);
	if (before > 0 && V.Phone.Battery <= 0) {
		T.phoneopen = false; // 关机黑屏
		return true;
	}
	return false;
};

// 充电(amount=恢复点数, 上限100)
PhoneMod.chargeBattery = function(amount) {
	if (!V.Phone || V.Phone.Stolen) return;
	V.Phone.Battery = Math.min(100, V.Phone.Battery + amount);
};

/* 充电点判定: 咖啡馆/学校按 location; 安全屋按 passage 白名单
   (孤儿院卧室/伊登小屋/海上平台/亚历克斯小屋/鹰塔)。 */
PhoneMod.canCharge = function() {
	if (!V.Phone || V.Phone.Stolen || !PhoneMod.isWorking()) return false;
	if (V.location === "cafe" || V.location === "school") return true;
	const safeHouses = ["Bedroom", "Eden Cabin", "Sea Platform Interior", "Sea Platform Bed", "Alex Cottage", "Bird Tower"];
	return safeHouses.includes(V.passage);
};

/* 上课中判定: 本体 $schoollesson===1 表示正在上课(第一~五节课),
   morning/lunch/afternoon 课间午休放学为 0。 */
PhoneMod.inClass = function() {
	return V.schoollesson === 1;
};

/* 上课期间锁定的耗时功能(约稿作画/打车/网购/相机)。
   聊天/发帖/闹钟/备忘录不耗时, 上课可以偷偷用。 */
PhoneMod.CLASS_LOCKED_APPS = ["commission", "taxi", "shop", "camera"];
PhoneMod.isClassLocked = function(appId) {
	return PhoneMod.inClass() && PhoneMod.CLASS_LOCKED_APPS.includes(appId);
};

/* 手机是否拿在手上且能开机: 硬件完好 && 有电 && 没被抢/偷 */
PhoneMod.isUsable = function() {
	return PhoneMod.isWorking() && V.Phone.Battery > 0 && !V.Phone.Stolen;
};

/* 丢失手机(被抢/被偷)。mode="combat"|"stolen"。
   丢失后弹窗收起, 次日起可在警察局失物招领领回。 */
PhoneMod.losePhone = function(mode) {
	if (!V.Phone || !V.Phone.Owned || V.Phone.Stolen) return;
	V.Phone.Stolen = mode;
	V.Phone._stolenDay = Time.days;
	V.Phone._incomingCall = null;
	T.phoneopen = false;
};

/* 失物招领领回: 被抢的可能被摔过(耐久-20), 被偷的原样归还。 */
PhoneMod.recoverPhone = function() {
	if (!V.Phone || !V.Phone.Stolen) return;
	if (V.Phone.Stolen === "combat") {
		V.Phone.Durability = Math.max(1, V.Phone.Durability - 20);
	}
	V.Phone.Stolen = null;
	V.Phone._stolenDay = -1;
};

// ==================== 耐久 / 型号 API ====================
// 获取当前型号对象, 无型号返回 null
PhoneMod.getModel = function() {
	if (!V.Phone || !V.Phone.Model) return null;
	return PhoneMod.PhoneModels[V.Phone.Model] || null;
};

// 手机是否完好可用(拥有 && 耐久>0)
PhoneMod.isWorking = function() {
	return !!(V.Phone && V.Phone.Owned && V.Phone.Model && V.Phone.Durability > 0);
};

// 耐久百分比 0-100
PhoneMod.durabilityPct = function() {
	const m = PhoneMod.getModel();
	if (!m) return 0;
	return Math.max(0, Math.min(100, Math.round(V.Phone.Durability / m.dur * 100)));
};

/* 损耗耐久。amount=损耗点数, reason=原因(预留, 可用于弹窗提示/日志)。
   返回 true 表示这次损耗导致手机彻底损坏。外部事件(战斗结算/绑架/落水等)
   直接 <<run PhoneMod.damagePhone(5)>> 即可。 */
PhoneMod.damagePhone = function(amount, reason) {
	if (!V.Phone || !V.Phone.Owned || V.Phone.Stolen) return false;
	if (V.Phone.Case) amount = Math.ceil(amount / 2); // 防摔手机壳: 损耗减半
	const before = V.Phone.Durability;
	V.Phone.Durability = Math.max(0, V.Phone.Durability - amount);
	if (before > 0 && V.Phone.Durability <= 0) {
		V.Phone._incomingCall = null; // 彻底坏了, 正在响的来电也接不到
		return true;
	}
	return false;
};

// 完全修复所需费用(便士): 每损失 1 点耐久 £1
PhoneMod.repairCost = function() {
	const m = PhoneMod.getModel();
	if (!m) return 0;
	return Math.max(0, m.dur - V.Phone.Durability) * 100;
};

// 执行完全修理(调用前先扣钱), 恢复满耐久
PhoneMod.repairFull = function() {
	const m = PhoneMod.getModel();
	if (!m) return;
	V.Phone.Durability = m.dur;
};

/* 以旧换新折价(便士): 旧机原价 × 剩余耐久比 × 25%, 向下取整到英镑。
   手机完全损坏时只剩残值 £10。 */
PhoneMod.tradeInValue = function() {
	if (!V.Phone || !V.Phone.Owned) return 0;
	const m = PhoneMod.getModel();
	if (!m) return 0;
	if (V.Phone.Durability <= 0) return 1000;
	return Math.floor(m.price * (V.Phone.Durability / m.dur) * 0.25 / 100) * 100;
};

/* 购买(更换)手机。modelId=型号, useTradeIn=是否以旧换新。
   返回 {ok:true} 或 {ok:false, reason:"poor"|"same"}。 */
PhoneMod.buyModel = function(modelId, useTradeIn) {
	const model = PhoneMod.PhoneModels[modelId];
	if (!model) return { ok: false, reason: "nomodel" };
	if (V.Phone.Owned && V.Phone.Model === modelId) return { ok: false, reason: "same" };
	let pay = model.price;
	if (useTradeIn && V.Phone.Owned) pay -= PhoneMod.tradeInValue();
	if (V.money < pay) return { ok: false, reason: "poor", cost: pay };
	V.money -= pay;
	V.Phone.Owned = true;
	V.Phone.Model = modelId;
	V.Phone.Durability = model.dur;
	V.Phone.CurrentApp = "main";
	V.Phone.CurrentChat = null;
	V.Phone._incomingCall = null;
	return { ok: true, cost: pay };
};

// ==================== APP 注册表 ====================
// 每个 APP: { name: 显示名, icon: emoji图标, widget: 对应 twee widget 名 }
PhoneMod.Apps = {
	contacts: { name: "通讯录", icon: "👥", widget: "phone_app_contacts" },
	messages: { name: "信息", icon: "💬", widget: "phone_app_messages" },
	shop:     { name: "淘夕夕", icon: "🛒", widget: "phone_app_shop" },
	taxi:     { name: "DoDo打车", icon: "🚕", widget: "phone_app_taxi" },
	alarm:    { name: "闹钟", icon: "⏰", widget: "phone_app_alarm" },
	memo:     { name: "备忘录", icon: "📝", widget: "phone_app_memo" },
	commission: { name: "约稿", icon: "🎨", widget: "phone_app_commission" },
	camera:   { name: "相机", icon: "📷", widget: "phone_app_camera" },
	album:    { name: "相册", icon: "🖼️", widget: "phone_app_album" },
	yenote:   { name: "jm", icon: "📖", widget: "phone_app_yenote" },
};

// ==================== UI 生命周期 ====================
// 阻止点击手机展开态内部时误触外部(原 inline onclick="event.stopPropagation()"
// 现改为引用函数, 避免 SugarCube 对事件对象的解析歧义)
PhoneMod.contentClick = function(event) {
	event.stopPropagation();
};

// 切换手机展开/收起（点击闭合状态手机展开，点锁屏按钮收起）
PhoneMod.togglePhone = function() {
	const phone = document.getElementById("myfirstmod-phone");
	if (!phone) return;
	phone.classList.toggle("phone-open");
	T.phoneopen = phone.classList.contains("phone-open");
};

// 切换 APP（设 CurrentApp 并重渲染）。坏机/没电/丢失不允许打开 APP。
// 上课期间锁定耗时功能(约稿/打车/网购/相机), 桌面显示提示条。
PhoneMod.toggleApp = function(appId) {
	if (!V.Phone) return;
	if (appId !== "main" && !PhoneMod.isUsable()) return;
	if (appId !== "main" && PhoneMod.isClassLocked(appId)) {
		T.phoneClassBlock = appId; // 提示哪个 APP 被锁
		PhoneMod.refresh();
		return;
	}
	T.phoneClassBlock = null;
	V.Phone.CurrentApp = appId;
	if (appId !== "messages") V.Phone.CurrentChat = null;
	PhoneMod.refresh();
};

// 刷新手机 UI（重新渲染 widget，保持展开状态）
PhoneMod.refresh = function() {
	const wrapper = document.getElementById("myfirstmod-phone-wrapper");
	if (!wrapper) return;
	wrapper.innerHTML = "";
	new Wikifier(wrapper, "<<phone_render>>");
	if (T.phoneopen) {
		document.getElementById("myfirstmod-phone")?.classList.add("phone-open");
	}
	// 对话视图: 绑定输入区 + 消息滚到底部
	PhoneMod.bindChatUI(wrapper);
};

// 跳转前保存现场（进入手机全屏界面：通话/商店等）
// 不重复保存：嵌套进入（如商店主页→服装专柜）时保留最初的现场
// targetPassage 省略时只保存现场+切 $location="phone", 由 twee 自行 goto
PhoneMod.PhoneTo = function(targetPassage) {
	if (!V.Phone) return;
	if (!PhoneMod.isWorking()) return;
	if (!V.Phone.ReturnPassage) {
		V.Phone.ReturnPassage = V.passage;
		V.Phone.ReturnOutside = V.outside;
		V.Phone.ReturnLocation = V.location;
	}
	V.location = "phone";
	V.Phone.CurrentApp = "main";
	V.Phone.CurrentChat = null;
	T.phoneopen = false;
	if (targetPassage) Engine.play(targetPassage);
};

// 恢复现场，返回目标 passage 名（供 <<PhoneBack>> widget / 动态链接使用）
PhoneMod.PhoneBack = function() {
	if (!V.Phone) return V.passage;
	let target = V.passage;
	if (V.Phone.ReturnLocation) {
		V.outside = V.Phone.ReturnOutside;
		V.location = V.Phone.ReturnLocation;
		target = V.Phone.ReturnPassage;
		delete V.Phone.ReturnPassage;
		delete V.Phone.ReturnOutside;
		delete V.Phone.ReturnLocation;
	}
	return target;
};

// 打车：真正前往目的地（不返回手机界面，故不保存现场、不切 location）
PhoneMod.travelTo = function(targetPassage) {
	T.phoneopen = false;
	if (V.Phone) { V.Phone.CurrentApp = "main"; V.Phone.CurrentChat = null; }
	Engine.play(targetPassage);
};

// ==================== 弹窗内短信聊天 ====================
// 打开与某人的对话（信息APP内部, 不跳 passage）
PhoneMod.openChat = function(contactId) {
	if (!V.Phone || !PhoneMod.isWorking()) return;
	V.Phone.CurrentChat = contactId;
	V.Phone.CurrentApp = "messages";
	// 进入对话时把对方发来的未读消息标记已读
	V.Phone.Messages.forEach(m => { if (m.from === contactId && m.to === "pc") m.read = true; });
	T.phoneTyping = null; // 清掉可能残留的"正在输入"
	PhoneMod.refresh();
};

// 关闭对话, 回到会话列表
PhoneMod.closeChat = function() {
	if (!V.Phone) return;
	V.Phone.CurrentChat = null;
	T.phoneTyping = null;
	PhoneMod.refresh();
};

/* 发送一条消息的两阶段交互:
   ① 玩家气泡立即入库并刷新; ② 显示"对方正在输入…"(T.phoneTyping);
   ③ 0.9~1.8 秒后对方回复入库, 清除打字态再刷新。
   纯前端延时: 期间若玩家已切走, 回复仍入库(当作迟到短信), 但不强制刷新。 */
PhoneMod.sendChat = function() {
	if (!V.Phone || !PhoneMod.isWorking()) return;
	if (T.phoneTyping) return; // 对方回复前禁止连发
	const text = (V.Phone._chatInput || "").trim();
	if (!text) return;
	const to = V.Phone.CurrentChat;
	PhoneMod.sendMessage(to, text);
	V.Phone._chatInput = "";
	PhoneMod._beginReply(to);
};

// 话题发送: 发送玩家选择的话题句子, 并用该话题的专属回复池安排对方回复
PhoneMod.sendTopic = function(topicIdx) {
	if (!V.Phone || !PhoneMod.isWorking() || T.phoneTyping) return;
	const to = V.Phone.CurrentChat;
	const topics = PhoneMod.chatTopics[to];
	if (!topics) return;
	const topic = topics[topicIdx];
	if (!topic) return;
	PhoneMod.sendMessage(to, topic.q);
	V.Phone._chatInput = "";
	PhoneMod._beginReply(to, topic);
};

// 内部: 进入"对方正在输入"并安排自动回复(topic 提供专属回复池)
PhoneMod._beginReply = function(to, topic) {
	/* 没有回复池的联系人发送后仅静默刷新, 气泡入库, 不假装对方正在打字。 */
	if (!PhoneMod.canReply(to, topic)) {
		PhoneMod.refresh();
		return;
	}
	T.phoneTyping = to;
	PhoneMod.refresh();
	const wrapperExists = () => !!document.getElementById("myfirstmod-phone-wrapper");
	setTimeout(function() {
		PhoneMod.autoReply(to, topic);
		T.phoneTyping = null;
		if (wrapperExists() && V.Phone.CurrentChat === to) PhoneMod.refresh();
	}, 900 + Math.floor(Math.random() * 900));
};

// 该联系人是否支持自动回复(话题带回复池即可回复)
PhoneMod.canReply = function(contactId, topic) {
	if (topic && topic.r && topic.r.length) return true;
	return !!(PhoneMod.chatTopics[contactId] && PhoneMod.chatTopics[contactId].length);
};

/* 聊天时间显示: 当天只显示 HH:MM, 跨天显示"第N天 HH:MM"。
   minute 缺省为 0(兼容旧消息)。 */
PhoneMod.formatChatTime = function(msg) {
	const hh = (msg.hour < 10 ? "0" : "") + msg.hour;
	const mm = ((msg.minute || 0) < 10 ? "0" : "") + (msg.minute || 0);
	if (typeof msg.day === "number" && typeof Time !== "undefined" && msg.day !== Time.days) {
		return "第" + msg.day + "天 " + hh + ":" + mm;
	}
	return hh + ":" + mm;
};

/* 会话列表用的简短时间: 当天 HH:MM, 更早只显示"第N天"。 */
PhoneMod.formatSessionTime = function(msg) {
	if (!msg) return "";
	if (typeof msg.day === "number" && typeof Time !== "undefined" && msg.day === Time.days) {
		const hh = (msg.hour < 10 ? "0" : "") + msg.hour;
		const mm = ((msg.minute || 0) < 10 ? "0" : "") + (msg.minute || 0);
		return hh + ":" + mm;
	}
	return "第" + msg.day + "天";
};

/* 联系人在线状态(供对话头部): 阿电按作息/课程返回 {text, cls}。
   其余已认识联系人统一"在线"。 */
PhoneMod.getContactStatus = function(contactId) {
	try {
		if (contactId === "adian") {
			if (Time.hour >= 23 || Time.hour < 6) return { text: "离线", cls: "off" };
			if (Time.hour >= 9 && Time.hour < 15 && !Time.weekEnd) return { text: "上课中", cls: "busy" };
			return { text: "在线", cls: "on" };
		}
	} catch (e) {}
	return { text: "在线", cls: "on" };
};

/* 玩家某条消息是否已读: 该消息之后存在对方发来的消息即视为已读,
   否则只是"送达"。index 为消息在与该联系人记录中的下标。 */
PhoneMod.isMessageRead = function(contactId, index) {
	const msgs = PhoneMod.getMessagesWith(contactId);
	for (let i = index + 1; i < msgs.length; i++) {
		if (msgs[i].from === contactId) return true;
	}
	return false;
};

/* 判断相邻两条消息是否需要重复显示时间/头像(同人且 10 分钟内则合并)。 */
PhoneMod.shouldShowTime = function(msgs, index) {
	const cur = msgs[index];
	if (index === 0) return true;
	const prev = msgs[index - 1];
	if (prev.from !== cur.from || prev.day !== cur.day) return true;
	const gap = Math.abs((cur.hour * 60 + (cur.minute || 0)) - (prev.hour * 60 + (prev.minute || 0)));
	return gap >= 10;
};

// 阿电快捷短语(青涩互动向; 仅在与阿电对话时显示)
/* 话题选项式对话: 每个联系人的可选话题, q=玩家发出的句子, r=对方回复池。
   点选话题即发送, 对方按所选话题回复(不再是自由输入)。 */
PhoneMod.chatTopics = {
	adian: [
		{ q: "在干嘛？", r: [
			"刚、刚修完一台收音机……没、没干嘛！",
			"在打游戏……诶，你居然主动发消息给我？",
			"躺着发呆。你、你怎么突然问这个。",
		]},
		{ q: "吃饭了吗", r: [
			"吃、吃了！……好吧是泡面。别管我！",
			"还没……你要请我？！我、我随便说说的，别当真。",
			"吃了，食堂。……你怎么比我妈还啰嗦。（没有嫌你烦的意思）",
		]},
		{ q: "想你了", r: [
			"诶？！！你、你突然说什么呢……",
			"……我也是。就、就一点点啊！不许笑！",
			"（对方输入了很久）……肉麻。早点睡。",
		]},
		{ q: "周末有空吗", r: [
			"有、有的！……咳，我是说，应该有空。怎么了？",
			"周末？你想干嘛……我、我可以把时间空出来。",
			"不知道，可能有事。……好吧没事，你约我就有空。",
		]},
		{ q: "晚安", r: [
			"晚安。……记得盖好被子。",
			"嗯，晚安。（这条他盯着屏幕看了好久才发出来）",
			"晚、晚安！你也早点睡，别熬夜。",
		]},
	],
	robin: [
		{ q: "今天过得怎么样？", r: [
			"还不错！柠檬水喝了个够，哈哈。",
			"挺好的！就是贝利又开始催我做家务了，唉。",
			"一般般吧……不过收到你的消息就好多了！",
		]},
		{ q: "在孤儿院还好吗？", r: [
			"一切都好！我给你留了点心，藏在我床底下，别告诉别人。",
			"还行，就是晚上有点吵。你什么时候回来呀？",
			"还好啦。贝利今天又发脾气了，不过我躲得快！",
		]},
		{ q: "需要我帮忙吗？", r: [
			"不用不用！你照顾好自己就行。",
			"你真好……其实我攒了点零花钱，下次请你吃冰激凌！",
			"暂时不用！不过说好了，有难要一起扛哦。",
		]},
		{ q: "晚安", r: [
			"晚安！明天见！",
			"晚安晚安！做个好梦～",
		]},
	],
	harper: [
		{ q: "我想预约就诊。", r: [
			"请通过诊所前台预约。我的日程排得很满。",
			"如果是复诊，直接来诊所即可。急诊请说明情况。",
		]},
		{ q: "上次的治疗有效果。", r: [
			"很好。按时复诊，有任何异常随时联系诊所。",
			"意料之中。继续保持。",
		]},
	],
	whitney: [
		{ q: "在干嘛？", r: [
			"关你屁事。",
			"在操场，有种你过来。",
			"你管得着吗？",
		]},
		{ q: "今天天气不错", r: [
			"……哈？你在跟我搭话？",
			"有病吧，天气好关我什么事。",
			"你是想挨打吗？",
		]},
		{ q: "作业借我抄一下", r: [
			"滚。",
			"你配吗？",
			"自己写去，别烦我。",
		]},
		{ q: "你为什么总欺负人？", r: [
			"因为看你们不爽。",
			"……你管太多了。",
			"想试试吗？",
		]},
	],
	avery: [
		{ q: "在干嘛？", r: [
			"刚参加完一个无聊的慈善晚宴。",
			"在书房看些投资报告，父亲要求的。",
			"和你有关系吗？不过……告诉你也无妨，在想晚餐吃什么。",
		]},
		{ q: "周末有空吗？", r: [
			"要看情况。父亲安排了马术课。",
			"如果你想约我……至少得提前三天预约。",
			"也许吧。你有车吗？",
		]},
		{ q: "听说你很有钱", r: [
			"这不是什么秘密。",
			"财富是一种责任，不是特权。……好吧，确实也挺特权的。",
			"你想借钱？",
		]},
		{ q: "学校里有人欺负我", r: [
			"告诉我名字。",
			"需要我帮你处理吗？我可以让那个人转班。",
			"这很常见，习惯就好。不过如果是你……我可以考虑帮忙。",
		]},
	],
	kylar: [
		{ q: "在干嘛？", r: [
			"……没干嘛。",
			"在看窗外。",
			"……你在关心我吗？",
		]},
		{ q: "今天天气不错", r: [
			"……嗯。",
			"我喜欢阴天。",
			"……你喜欢就好。",
		]},
		{ q: "你还好吗？", r: [
			"……为什么问这个？",
			"不好。但看到你消息……好一点了。",
			"……你会一直问吗？",
		]},
		{ q: "我想了解你", r: [
			"……为什么？",
			"我没什么好了解的。",
			"……那你想知道什么？",
		]},
	],
	sydney: [
		{ q: "在干嘛？", r: [
			"在教堂帮忙整理捐赠物资。",
			"刚做完祷告。",
			"在花园里看书。你也喜欢阅读吗？",
		]},
		{ q: "今天过得怎么样？", r: [
			"很充实！帮助了很多人。",
			"有点累，但很开心。",
			"挺好的，就是有点想你了。……啊，我是说，作为朋友！",
		]},
		{ q: "教堂的工作辛苦吗？", r: [
			"不辛苦，这是主的旨意。",
			"能帮助别人就很满足。",
			"有时候会累，但很有意义。",
		]},
		{ q: "周末有空吗？", r: [
			"周六上午有弥撒，下午有空。",
			"如果你需要我，我可以调整时间。",
			"要和……和你一起吗？我可以！",
		]},
	],
};

/* 会话列表数据: 已认识联系人 + 最后一条消息 + 未读数, 按最后消息时间倒序,
   从未聊过的沉底。供 phone_app_messages 列表视图遍历。 */
PhoneMod.getChatSessions = function() {
	if (!V.Phone) return [];
	return V.Phone.Contacts.filter(c => c.known).map(function(c) {
		const msgs = PhoneMod.getMessagesWith(c.id);
		const last = msgs.length ? msgs[msgs.length - 1] : null;
		const unread = V.Phone.Messages.filter(function(m) {
			return m.from === c.id && m.to === "pc" && !m.read;
		}).length;
		return { contact: c, last: last, unread: unread };
	}).sort(function(a, b) {
		if (!a.last) return 1;
		if (!b.last) return -1;
		const ta = a.last.day * 1440 + a.last.hour * 60 + (a.last.minute || 0);
		const tb = b.last.day * 1440 + b.last.hour * 60 + (b.last.minute || 0);
		return tb - ta;
	});
};

/* refresh 后: 绑定对话输入框(空内容禁用发送)并把消息滚到底部。
   每次 refresh 都是全新 DOM, 直接绑定即可。 */
PhoneMod.bindChatUI = function(wrapper) {
	const chatBody = wrapper.querySelector(".phone-chat-body");
	if (chatBody) chatBody.scrollTop = chatBody.scrollHeight;
	const form = wrapper.querySelector(".phone-chat-input");
	if (!form) return;
	const input = form.querySelector("input");
	const submit = form.querySelector("button[type=submit]");
	if (!input || !submit) return;
	input.placeholder = "发条消息…"; // SugarCube textbox 宏无 placeholder 参数, 用 DOM 设置
	const sync = function() {
		const typing = !!T.phoneTyping;
		submit.disabled = typing || !input.value.trim();
		input.disabled = typing;
	};
	input.addEventListener("input", sync);
	form.addEventListener("submit", function() { setTimeout(sync, 0); });
	sync();
};

// ==================== 渲染钩子 + 事件损耗 ====================
$(document).on(":passagerender", function(ev) {
	PhoneMod.initState();
	if (!V.Phone.Owned) return;
	if (V.passage === "Start") return;

	/* ---- 耐久事件损耗(在战斗/全屏手机界面的 return 之前执行) ---- */
	// ① 战斗: 用 _wasCombat 做边沿检测, 每场战斗开始时损耗一次
	if (V.combat === 1) {
		if (V.Phone._wasCombat !== 1) {
			PhoneMod.damagePhone(random(3, 8), "combat");
			PhoneMod.drainBattery(random(5, 12), "combat");
			V.Phone._flashUsed = 0; // 每场战斗闪光灯次数重置
			// 极低概率被抢走(1.5%), 当场失去手机(次日警察局招领)
			if (Math.random() < 0.015) {
				PhoneMod.losePhone("combat");
				try { V.Phone._wasCombat = 1; } catch(e) {}
				return; // 被抢走了, 后面不渲染手机
			}
		}
		V.Phone._wasCombat = 1;
		// 战斗中: 闪光灯按钮(每场限2次, 耗电15, 扣全体敌人血量上限5%)
		PhoneMod.injectFlashButton();
	} else {
		V.Phone._wasCombat = 0;
		// ② 暴雨户外进水
		try {
			if (V.outside === 1 && typeof Weather !== "undefined" &&
				Weather.precipitation === "rain" &&
				typeof Weather.precipitationIntensity === "number" &&
				Weather.precipitationIntensity >= 1.3 &&
				V.Phone._rainDay !== Time.days) {
				V.Phone._rainDay = Time.days;
				if (Math.random() < 0.3) PhoneMod.damagePhone(random(1, 3), "rain");
			}
		} catch (e) {}
		// ③ 街头扒窃(每天一次判定): 在室外+手机在身上+非战斗中
		if (V.outside === 1 && !V.Phone.Stolen && V.Phone._theftDay !== Time.days) {
			V.Phone._theftDay = Time.days;
			// 白天人流多风险高(0.8%), 深夜安静风险低(0.3%)
			const theftRate = (Time.hour >= 6 && Time.hour < 22) ? 0.008 : 0.003;
			if (Math.random() < theftRate) {
				PhoneMod.losePhone("stolen");
				return; // 被偷了不渲染
			}
		}
		// ④ 全天候微量待机耗电(每跨过一个整点扣1点, 充电时豁免)
		let _curPassage = "";
		try { _curPassage = (typeof passage === "function") ? passage() : (V.passage || ""); } catch (e) {}
		if (_curPassage !== "Phone Charge") {
			if (typeof V.Phone._idleHour !== "number") V.Phone._idleHour = Time.hour;
			if (Time.hour !== V.Phone._idleHour) {
				V.Phone._idleHour = Time.hour;
				PhoneMod.drainBattery(1, "idle");
			}
		}
	}
	// ⑤ 电量耗尽即关机(不渲染手机)
	if (V.Phone.Battery <= 0 || V.Phone.Stolen) return;

	// 战斗中 / 手机全屏界面($location="phone")不显示浮动外壳
	if (V.combat === 1) return;
	if (V.location === "phone") return;

	const wrapper = document.createElement("div");
	wrapper.id = "myfirstmod-phone-wrapper";
	$(ev.content).append(wrapper);
	new Wikifier(wrapper, "<<phone_render>>");

	if (T.phoneopen) {
		document.getElementById("myfirstmod-phone")?.classList.add("phone-open");
	}
});

// ==================== 掏夕夕次日达 ====================
/* 商品表: id/名称/价格(便士)/图标/效果说明。
   deliverDay = 下单日(Time.days) + 1, 第二天送达。 */
setup.phoneShopItems = [
	{ id: "phoneCase", name: "防摔手机壳", price: 1500, icon: "🛡️", desc: "给手机套个壳。耐久损耗减半, 新壳才有效。", effect: "phoneCase" },
	{ id: "battery", name: "便携充电宝", price: 1200, icon: "🔋", desc: "插上就能回血。立即恢复 50% 电量。", effect: "battery50" },
	{ id: "sketchbook", name: "速写本", price: 1500, icon: "📓", desc: "练手用的速写本, 画画人的基础装备。", effect: "sketchbook" },
	{ id: "tablet", name: "入门数位板", price: 12000, icon: "🖥️", desc: "连手机就能用。约稿接单、画本子都靠它。", effect: "tablet" },
	{ id: "choco", name: "高级巧克力", price: 2000, icon: "🍫", desc: "送人的小礼物。也许有人会喜欢。", effect: "giftChoco" },
];

/* 下单。返回 {ok, reason}。商品加入待收货列表 V.Phone.Orders。 */
PhoneMod.buyShopItem = function(itemId) {
	const item = setup.phoneShopItems.find(i => i.id === itemId);
	if (!item) return { ok: false, reason: "noitem" };
	if (V.money < item.price) return { ok: false, reason: "poor", cost: item.price };
	V.money -= item.price;
	const deliverDay = Time.days + 1;
	V.Phone.Orders.push({
		id: item.id,
		name: item.name,
		price: item.price,
		icon: item.icon,
		orderedDay: Time.days,
		deliverDay: deliverDay,   // 预计送达日
		delivered: false,        // 是否已签收
	});
	return { ok: true, cost: item.price, deliverDay: deliverDay };
};

/* 检查是否有可签收的快递(到 deliverDay 自动变成 delivered)。
   打开 APP 时调用一次, 避免每帧都跑。 */
PhoneMod.checkDeliveries = function() {
	if (!V.Phone || !V.Phone.Orders) return;
	let changed = false;
	V.Phone.Orders.forEach(o => {
		if (!o.delivered && Time.days >= o.deliverDay) {
			o.delivered = true;
			changed = true;
		}
	});
	return changed;
};

/* 签收包裹。idx = 在 Orders 中的下标。签收时给效果。 */
PhoneMod.claimOrder = function(idx) {
	const o = V.Phone.Orders[idx];
	if (!o || !o.delivered) return { ok: false };
	let result = { ok: true, name: o.name, effectText: "" };
	const item = setup.phoneShopItems.find(i => i.id === o.id);
	if (item) {
		switch (item.effect) {
			case "phoneCase":
				V.Phone.Case = true;
				result.effectText = "手机壳装好了, 感觉安心多了。";
				break;
			case "battery50":
				PhoneMod.chargeBattery(50);
				result.effectText = "电量恢复了 50%。";
				break;
			case "sketchbook":
				V.paintingGear.sketchbook = true;
				result.effectText = "速写本拿到手了, 随时可以练画。";
				break;
			case "tablet":
				V.paintingGear.tablet = true;
				result.effectText = "数位板连上手机, 约稿接单都解锁了。";
				break;
			case "giftChoco":
				// 巧克力不存仓库, 直接在物品栏生成一个"待送出的巧克力"
				if (!V.Phone.Gifts) V.Phone.Gifts = [];
				V.Phone.Gifts.push({ id: "choco", name: "高级巧克力", day: Time.days });
				result.effectText = "包好放进口袋, 见到那个人时可以送出去。";
				break;
		}
	}
	V.Phone.Orders.splice(idx, 1); // 签收后从列表移除
	return result;
};

/* 获取待签收包裹列表(未送达+已送达混在一起, 供 APP 渲染) */
PhoneMod.getPendingOrders = function() {
	if (!V.Phone || !V.Phone.Orders) return [];
	PhoneMod.checkDeliveries();
	return V.Phone.Orders;
};

// ==================== 战斗闪光灯 ====================
/* 战斗中往页面右上角注入闪光灯按钮。
   每场战斗最多用 2 次, 每次耗电 15 点;
   按下瞬间扣除全体敌人各自"血量上限"的 5% 作为真实伤害。 */
PhoneMod.injectFlashButton = function() {
	if (!V.Phone || !PhoneMod.isUsable()) return;
	if (V.Phone._flashUsed >= 2) return; // 每场限2次
	if (V.Phone.Battery < 15) return;    // 电量不足15不显示(拍不动)
	// 已注入则不重复
	if (document.getElementById("myfirstmod-flash-btn")) return;
	const btn = document.createElement("button");
	btn.id = "myfirstmod-flash-btn";
	btn.textContent = "📸 闪光灯";
	btn.title = "消耗15%电量, 闪瞎敌人(各自扣血量上限5%)";
	btn.onclick = function() { PhoneMod.useFlash(); };
	document.body.appendChild(btn);
};

/* 闪光灯效果: 扣电 + 全体敌人血量上限5%真实伤害(不是当前血量)。
   本体敌人血量在 $NPCList[i].health, 上限 healthmax;
   $enemyhealth 是聚合显示血条, 也要同步扣。 */
PhoneMod.useFlash = function() {
	if (!V.Phone || !PhoneMod.isUsable()) return;
	if (V.Phone.Battery < 15) return;
	if (V.Phone._flashUsed >= 2) return;

	V.Phone._flashUsed += 1;
	PhoneMod.drainBattery(15, "flash");

	let hitCount = 0;
	if (Array.isArray(V.NPCList)) {
		V.NPCList.forEach(npc => {
			if (npc && typeof npc.health === "number" && npc.health > 0) {
				const maxHp = typeof npc.healthmax === "number" && npc.healthmax > 0 ? npc.healthmax : npc.health;
				const dmg = Math.max(1, Math.floor(maxHp * 0.05));
				npc.health = Math.max(0, npc.health - dmg);
				hitCount++;
			}
		});
	}
	// 聚合血条同步
	if (typeof V.enemyhealth === "number" && typeof V.enemyhealthmax === "number" && V.enemyhealthmax > 0) {
		const totalDmg = Math.max(1, Math.floor(V.enemyhealthmax * 0.05));
		V.enemyhealth = Math.max(0, V.enemyhealth - totalDmg);
	}

	// 移除按钮, 给个反馈
	const btn = document.getElementById("myfirstmod-flash-btn");
	if (btn) btn.remove();
	const msg = hitCount > 0
		? `📸 闪光灯亮起, ${hitCount} 名敌人被晃花了眼(血量上限5%削减)!`
		: "📸 闪光灯亮了一下, 但没有敌人可闪。";
	if (typeof Wikifier !== "undefined") {
		new Wikifier(null, `<<run PhoneMod.refresh()>>`);
	}
	// 用本体错误汇报通道不太合适, 直接弹 toast 风格提示
	const tip = document.createElement("div");
	tip.className = "myfirstmod-flash-tip";
	tip.textContent = msg;
	document.body.appendChild(tip);
	setTimeout(() => tip.remove(), 2500);
};

// ==================== 工具函数 ====================
// 获取时间字符串 HH:MM
PhoneMod.getTimeString = function() {
	const h = Time.hour < 10 ? "0" + Time.hour : Time.hour;
	const m = Time.minute < 10 ? "0" + Time.minute : Time.minute;
	return h + ":" + m;
};

// 获取日期字符串
PhoneMod.getDateString = function() {
	const days = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
	return Time.month + "月" + Time.day + "日 " + days[Time.weekDay];
};

// 添加/更新联系人
PhoneMod.addContact = function(id, name, desc) {
	if (!V.Phone) return;
	const existing = V.Phone.Contacts.find(c => c.id === id);
	if (existing) {
		existing.known = true;
		if (desc) existing.desc = desc;
	} else {
		V.Phone.Contacts.push({ id: id, name: name, known: true, desc: desc || "" });
	}
};

// 收到消息（NPC发给自己）
PhoneMod.receiveMessage = function(fromId, text) {
	if (!V.Phone) return;
	V.Phone.Messages.push({
		from: fromId,
		to: "pc",
		text: text,
		day: Time.days,
		hour: Time.hour,
		minute: Time.minute,
		read: V.Phone.CurrentChat === fromId,  // 正在看对话时直接算已读
	});
};

// 玩家发送消息
PhoneMod.sendMessage = function(toId, text) {
	if (!V.Phone) return;
	V.Phone.Messages.push({
		from: "pc",
		to: toId,
		text: text,
		day: Time.days,
		hour: Time.hour,
		minute: Time.minute,
		read: true,
	});
};

// 获取与某人的消息记录
PhoneMod.getMessagesWith = function(contactId) {
	if (!V.Phone) return [];
	return V.Phone.Messages.filter(m =>
		(m.from === contactId && m.to === "pc") || (m.from === "pc" && m.to === contactId)
	);
};

// 阿电短信自动回复（青涩纯情风格，随机一句）
PhoneMod.adianReplies = [
	"……嗯。",
	"哦哦，好。",
	"知道了。",
	"你、你现在在干嘛？",
	"……没什么，就是看看你在不在。",
	"嗯，我也是。",
	"晚点……晚点见面再说吧。",
	"我、我先去忙了！（其实不忙）",
];

/* 各联系人的自动回复。只有阿电有回复池; 其他联系人暂未实装,
   发消息不会收到回复(对话里只显示玩家自己发的)。 */
PhoneMod.autoReply = function(toId, topic) {
	if (topic && topic.r && topic.r.length) {
		const r = topic.r[Math.floor(Math.random() * topic.r.length)];
		PhoneMod.receiveMessage(toId, r);
		return;
	}
	// 回退: 旧版兼容(未传 topic 时)
	if (toId === "adian") {
		const r = PhoneMod.adianReplies[Math.floor(Math.random() * PhoneMod.adianReplies.length)];
		PhoneMod.receiveMessage("adian", r);
	}
};

// 检查未读消息数
PhoneMod.getUnreadCount = function() {
	if (!V.Phone) return 0;
	return V.Phone.Messages.filter(m => !m.read && m.to === "pc").length;
};

// 拒接来电
PhoneMod.rejectCall = function() {
	if (!V.Phone) return;
	V.Phone._incomingCall = null;
	PhoneMod.refresh();
};

// 获取联系人名字（供消息列表用）
PhoneMod.getContactName = function(id) {
	if (!V.Phone) return id;
	const c = V.Phone.Contacts.find(c => c.id === id);
	return c ? c.name : id;
};

// 备忘录：切换完成状态
PhoneMod.toggleMemoDone = function(id) {
	if (!V.Phone) return;
	const m = V.Phone.Memo.find(m => m.id === id);
	if (m) m.done = !m.done;
	PhoneMod.refresh();
};

// 备忘录：删除
PhoneMod.deleteMemo = function(id) {
	if (!V.Phone) return;
	V.Phone.Memo = V.Phone.Memo.filter(m => m.id !== id);
	PhoneMod.refresh();
};

// ==================== 打车系统(动态距离计价) ====================
// 本体街道邻接表(逆向自 Widget mapAvailableData 743176-743200, 无向图)。
// 打车只在街面下车, 不直接送进建筑/学校/码头内部。
PhoneMod.STREET_GRAPH = {
	"Domus Street": ["Barb Street", "Danube Street", "Residential Alleyways"],
	"Barb Street": ["Domus Street", "Cliff Street", "Connudatus Street", "Residential Alleyways"],
	"Danube Street": ["Domus Street", "Wolf Street", "Connudatus Street", "Residential Alleyways"],
	"Connudatus Street": ["Barb Street", "Danube Street", "Cliff Street", "Wolf Street", "Residential Alleyways", "Commercial Alleyways"],
	"Cliff Street": ["Barb Street", "Starfish Street", "Connudatus Street", "High Street", "Commercial Alleyways"],
	"Wolf Street": ["Danube Street", "Nightingale Street", "Connudatus Street", "High Street", "Commercial Alleyways"],
	"High Street": ["Cliff Street", "Wolf Street", "Starfish Street", "Nightingale Street", "Commercial Alleyways", "Park"],
	"Starfish Street": ["Cliff Street", "Mer Street", "High Street", "Oxford Street", "Park"],
	"Nightingale Street": ["Wolf Street", "Elk Street", "High Street", "Oxford Street", "Park"],
	"Oxford Street": ["Starfish Street", "Nightingale Street", "Mer Street", "Elk Street", "Park", "Industrial Alleyways"],
	"Mer Street": ["Starfish Street", "Oxford Street", "Harvest Street", "Industrial Alleyways"],
	"Elk Street": ["Nightingale Street", "Oxford Street", "Harvest Street", "Industrial Alleyways"],
	"Harvest Street": ["Mer Street", "Elk Street", "Industrial Alleyways"],
	"Residential Alleyways": ["Domus Street", "Barb Street", "Danube Street", "Connudatus Street", "Commercial Alleyways"],
	"Commercial Alleyways": ["Connudatus Street", "Cliff Street", "Wolf Street", "High Street", "Residential Alleyways", "Park"],
	"Park": ["High Street", "Starfish Street", "Oxford Street", "Nightingale Street", "Commercial Alleyways", "Industrial Alleyways"],
	"Industrial Alleyways": ["Oxford Street", "Mer Street", "Elk Street", "Harvest Street", "Park"],
};

// 城外特殊节点: 折到最近街道锚点 + 附加车程(林道/田道车开不快)
PhoneMod.ZONE_EXTRA = {
	forest: { anchor: "Harvest Street", add: 4 },
	farm:   { anchor: "Harvest Street", add: 2 },
};

// BFS 最短街数
PhoneMod.streetHops = function(a, b) {
	if (a === b) return 0;
	const q = [[a, 0]]; const seen = { [a]: 1 };
	while (q.length) {
		const [node, d] = q.shift();
		const next = PhoneMod.STREET_GRAPH[node] || [];
		for (let i = 0; i < next.length; i++) {
			if (next[i] === b) return d + 1;
			if (!seen[next[i]]) { seen[next[i]] = 1; q.push([next[i], d + 1]); }
		}
	}
	return 6; // 图不连通的兜底
};

// 任意两个 zone(含城外伪节点)之间的车程跳数
PhoneMod.zoneHops = function(a, b) {
	if (a === b) return 0;
	const ea = PhoneMod.ZONE_EXTRA[a] || { anchor: a, add: 0 };
	const eb = PhoneMod.ZONE_EXTRA[b] || { anchor: b, add: 0 };
	return PhoneMod.streetHops(ea.anchor, eb.anchor) + ea.add + eb.add;
};

/* 室内/建筑 passage → 最近街道 zone 映射(全等优先, 其次前缀)。
   记录玩家当前所在地, 原地叫车不收钱不耗时。 */
PhoneMod.INTERIOR_ZONE = {
	"Shopping Centre": "High Street",
	"Supermarket": "High Street",
	"School Front Courtyard": "Oxford Street",
	"School": "Oxford Street",
	"Canteen": "Oxford Street",
	"Hospital": "Nightingale Street",
	"Ocean Breeze": "Cliff Street",
	"Beach": "Starfish Street",
	"Arcade": "Starfish Street",
	"Pound": "Starfish Street",
	"Chalets": "Starfish Street",
	"Docks": "Mer Street",
	"Brothel": "Elk Street",
	"Strip Club": "Elk Street",
	"Park": "Park",
	"Orphanage": "Domus Street",
	"Bedroom": "Domus Street",
	"Police": "Danube Street",
	"Forest": "forest",
	"Farm": "farm",
};

PhoneMod.getCurrentZone = function() {
	let p = "";
	try { p = (typeof passage === "function") ? passage() : (State.active ? State.active.title : ""); }
	catch (e) { p = ""; }
	if (!p) return null;
	if (PhoneMod.STREET_GRAPH[p]) return p;
	if (PhoneMod.INTERIOR_ZONE[p]) return PhoneMod.INTERIOR_ZONE[p];
	const keys = Object.keys(PhoneMod.INTERIOR_ZONE);
	for (let i = 0; i < keys.length; i++) {
		if (p.indexOf(keys[i]) === 0) return PhoneMod.INTERIOR_ZONE[keys[i]];
	}
	return null; // 海上平台/伊登小屋等野外安全屋无法定位
};

/* 计价: 起步 £3(含接单调度), 每过一条街 +£1; 每跳车程 2 分钟 + 等车 3 分钟。
   原地(已在目标街区)不可叫车, 0 费 0 时。定位失败按多姆斯街(孤儿院)估。 */
PhoneMod.taxiInfo = function(zone) {
	const cur = PhoneMod.getCurrentZone() || "Domus Street";
	if (zone === cur) return { here: true, price: 0, minutes: 0, hops: 0 };
	const hops = PhoneMod.zoneHops(cur, zone);
	return { here: false, price: 300 + hops * 100, minutes: 3 + hops * 2, hops: hops };
};

// 叫车: 校验+扣费+进入上车过程 passage(时间在 widget payload 里 <<pass>>)
PhoneMod.startTaxiRide = function(destId) {
	if (!V.Phone) return;
	const d = setup.phoneTaxiDestinations.find(x => x.id === destId);
	if (!d) return;
	const info = PhoneMod.taxiInfo(d.zone);
	if (info.here || V.money < info.price) return;
	V.money -= info.price;
	V.Phone._taxiDest = d.passage;
	V.Phone._taxiName = d.name;
	V.Phone._taxiMinutes = info.minutes;
	T.phoneopen = false;
	V.Phone.CurrentApp = "main";
	V.Phone.CurrentChat = null;
	Engine.play("Phone Taxi Ride");
};

// 打车目的地: 全部为街面/城外下车点, zone 用于距离计算
setup.phoneTaxiDestinations = [
	{ id: "high",        name: "商业街",       desc: "购物中心·写字楼",   passage: "High Street",        zone: "High Street" },
	{ id: "park",        name: "公园",         desc: "",                  passage: "Park",               zone: "Park" },
	{ id: "cliff",       name: "悬崖街",       desc: "海风咖啡馆",        passage: "Cliff Street",       zone: "Cliff Street" },
	{ id: "wolf",        name: "狼街",         desc: "",                  passage: "Wolf Street",        zone: "Wolf Street" },
	{ id: "nightingale", name: "南丁格尔街",   desc: "医院",              passage: "Nightingale Street", zone: "Nightingale Street" },
	{ id: "oxford",      name: "牛津街",       desc: "学校",              passage: "Oxford Street",      zone: "Oxford Street" },
	{ id: "starfish",    name: "海星街",       desc: "去海滩在这下",      passage: "Starfish Street",    zone: "Starfish Street" },
	{ id: "mer",         name: "梅尔街",       desc: "码头",              passage: "Mer Street",         zone: "Mer Street" },
	{ id: "elk",         name: "麋鹿街",       desc: "红灯区",            passage: "Elk Street",         zone: "Elk Street" },
	{ id: "harvest",     name: "丰收街",       desc: "镇东近郊",          passage: "Harvest Street",     zone: "Harvest Street" },
	{ id: "danube",      name: "多瑙河街",     desc: "警察局",            passage: "Danube Street",      zone: "Danube Street" },
	{ id: "connudatus",  name: "康努达塔斯街", desc: "集市",              passage: "Connudatus Street",  zone: "Connudatus Street" },
	{ id: "domus",       name: "多姆斯街",     desc: "孤儿院",            passage: "Domus Street",       zone: "Domus Street" },
	{ id: "barb",        name: "巴布街",       desc: "",                  passage: "Barb Street",        zone: "Barb Street" },
	{ id: "forest",      name: "森林",         desc: "镇外林边",          passage: "Forest",             zone: "forest" },
	{ id: "farm",        name: "农场",         desc: "亚历克斯家的农场",  passage: "Farmland",           zone: "farm" },
];
